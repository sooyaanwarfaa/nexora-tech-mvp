"""Payment providers.

Two providers ship in the box:
  SIMULATED -- customer sees a fake gateway page with Approve / Decline (demo + testing).
  GATEWAY   -- a generic hosted-checkout mobile-money / card gateway (Zaad, e-Dahab, EVC Plus
               aggregators, Stripe-style hosted pages...). It is configured by env vars and
               speaks one small JSON contract; adapt `initiate` / `parse_webhook` to whatever
               your verified provider's API actually looks like.

  NEXORA_PAY_API_URL         POST endpoint that creates a payment
  NEXORA_PAY_API_KEY         sent as  Authorization: Bearer <key>
  NEXORA_PAY_WEBHOOK_SECRET  shared secret used to verify webhook signatures (HMAC-SHA256)
  NEXORA_PAY_CURRENCY        default USD
"""
import hashlib
import hmac
import json
import os
import urllib.request

PROVIDERS = {"SIMULATED": "Simulated (demo only)", "GATEWAY": "Live payment gateway"}


class PaymentError(Exception):
    pass


def gateway_configured():
    return bool(os.environ.get("NEXORA_PAY_API_URL") and os.environ.get("NEXORA_PAY_WEBHOOK_SECRET"))


def initiate(provider, txn_id, amount, phone, callback_url, return_url):
    """Starts a payment. Returns (provider_ref, redirect_url_or_None). Raises PaymentError."""
    if provider == "SIMULATED":
        return "SIM-" + txn_id[-8:], None
    if provider != "GATEWAY" or not gateway_configured():
        raise PaymentError("Online payment is not configured.")
    body = json.dumps({
        "reference": txn_id, "amount": round(amount, 2),
        "currency": os.environ.get("NEXORA_PAY_CURRENCY", "USD"),
        "customer_phone": phone or "", "callback_url": callback_url, "return_url": return_url,
    }).encode()
    req = urllib.request.Request(
        os.environ["NEXORA_PAY_API_URL"], data=body, method="POST",
        headers={"Content-Type": "application/json", "Idempotency-Key": txn_id,
                 "Authorization": "Bearer " + os.environ.get("NEXORA_PAY_API_KEY", "")})
    try:
        data = json.loads(urllib.request.urlopen(req, timeout=10).read())
    except Exception as e:
        raise PaymentError("Could not reach the payment provider.") from e
    if not data.get("checkout_url"):
        raise PaymentError("The payment provider did not return a checkout page.")
    return str(data.get("provider_ref") or ""), data["checkout_url"]


def sign(body: bytes) -> str:
    return hmac.new(os.environ.get("NEXORA_PAY_WEBHOOK_SECRET", "").encode(), body, hashlib.sha256).hexdigest()


def verify_signature(body: bytes, signature: str) -> bool:
    if not gateway_configured() or not signature:
        return False
    return hmac.compare_digest(sign(body), signature.strip().lower())


def parse_webhook(payload: dict):
    """Returns (transaction_id, 'PAID'|'FAILED'|None, provider_ref, amount_or_None)."""
    status = str(payload.get("status", "")).upper()
    outcome = "PAID" if status in ("SUCCESS", "SUCCEEDED", "PAID", "COMPLETED") else \
              "FAILED" if status in ("FAILED", "DECLINED", "CANCELLED", "EXPIRED") else None
    amount = payload.get("amount")
    return payload.get("reference"), outcome, str(payload.get("provider_ref") or ""), \
        float(amount) if amount is not None else None
