import functools
import hashlib
import hmac
import json
import os
import secrets
import urllib.request
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

from flask import Flask, render_template, request, redirect, url_for, session, jsonify, g, abort, flash, Response
from werkzeug.security import generate_password_hash, check_password_hash

import payments
from db import get_db, init_db, seed_demo_data
from qr import qr_svg

app = Flask(__name__)


# ---------------------------------------------------------------------------
# Advanced permissions -- fine-grained control over what an admin account can do.
# All four base roles (admin/cashier/kitchen/waiter) are unchanged; this only lets
# one admin restrict what ANOTHER admin account can see or manage (e.g. a "manager"
# admin who can run the floor but can't touch staff, permissions, or the API).
# ---------------------------------------------------------------------------

ADMIN_PERMISSIONS = [
    "settings.manage", "menu.manage", "tables.manage", "staff.manage", "branches.manage",
    "promotions.manage", "inventory.manage", "customers.manage", "reservations.manage",
    "feedback.view", "performance.view", "api_keys.manage", "accounting.manage",
    "payments.manage", "audit.view", "permissions.manage",
]
PERMISSION_LABELS = {
    "settings.manage": "Restaurant details", "menu.manage": "Menu", "tables.manage": "Tables",
    "staff.manage": "Staff accounts", "branches.manage": "Branches", "promotions.manage": "Promotions",
    "inventory.manage": "Inventory", "customers.manage": "Customers & loyalty",
    "reservations.manage": "Reservations", "feedback.view": "Customer feedback",
    "performance.view": "Staff performance", "api_keys.manage": "API keys",
    "accounting.manage": "Accounting integration", "payments.manage": "Payments", "audit.view": "Audit log",
    "permissions.manage": "Permissions",
}


def revoked_perms_for(user_id):
    row = get_db_conn().execute("SELECT revoked_permissions FROM users WHERE id = ?", (user_id,)).fetchone()
    raw = row["revoked_permissions"] if row else ""
    return set(p for p in (raw or "").split(",") if p)


def require_perm(perm):
    """Stacks under @login_required('admin'): blocks this one admin account from a
    specific admin area if another admin has revoked that permission from them."""
    def decorator(view):
        @functools.wraps(view)
        def wrapped(*args, **kwargs):
            if perm in revoked_perms_for(session["user_id"]):
                abort(403)
            return view(*args, **kwargs)
        return wrapped
    return decorator


def log_admin_action(db, action, details=""):
    db.execute("INSERT INTO audit_log (restaurant_id, user_id, action, details) VALUES (?, ?, ?, ?)",
               (session.get("restaurant_id"), session.get("user_id"), action, details))


def send_accounting_webhook(db, restaurant_id, order_id, event):
    """Best-effort push of a sale/refund to an external accounting system. Never
    raises -- a slow or unreachable endpoint must not block a customer's checkout."""
    url = db.execute("SELECT accounting_webhook_url FROM restaurants WHERE id = ?", (restaurant_id,)).fetchone()
    url = url["accounting_webhook_url"] if url else ""
    if not url:
        return
    order = db.execute(
        "SELECT id, order_type, subtotal, discount, delivery_fee, loyalty_redeemed_value, total, "
        "payment_status, status, placed_at FROM orders WHERE id = ?", (order_id,)
    ).fetchone()
    if order is None:
        return
    payload = {
        "event": event, "restaurant_id": restaurant_id, "order_id": order["id"],
        "order_type": order["order_type"], "subtotal": order["subtotal"], "discount": order["discount"],
        "delivery_fee": order["delivery_fee"], "loyalty_redeemed_value": order["loyalty_redeemed_value"],
        "total": order["total"], "payment_status": order["payment_status"], "status": order["status"],
        "placed_at": order["placed_at"],
    }
    try:
        req = urllib.request.Request(
            url, data=json.dumps(payload).encode(), method="POST",
            headers={"Content-Type": "application/json", "User-Agent": "NexoraTech-Accounting/1"},
        )
        urllib.request.urlopen(req, timeout=4)
    except Exception:
        pass  # best-effort only -- never break the customer-facing flow


def load_secret_key():
    """Env var wins; otherwise a key is generated once and kept in .secret_key so
    staff stay logged in across restarts."""
    env_key = os.environ.get("NEXORA_SECRET_KEY")
    if env_key:
        return env_key
    key_file = Path(__file__).parent / ".secret_key"
    if key_file.exists():
        return key_file.read_text().strip()
    key = secrets.token_hex(32)
    key_file.write_text(key)
    return key


IS_PRODUCTION = os.environ.get("NEXORA_ENV", "").lower() == "production"
if IS_PRODUCTION and not os.environ.get("NEXORA_SECRET_KEY"):
    raise RuntimeError("NEXORA_SECRET_KEY must be set when NEXORA_ENV=production")
app.secret_key = load_secret_key()
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("NEXORA_PUBLIC_URL", "").startswith("https://"),
    MAX_CONTENT_LENGTH=2 * 1024 * 1024,
)


# ---------------------------------------------------------------------------
# CSRF protection: every POST needs the per-session token (hidden form field added
# automatically by static/js/csrf.js, or the X-CSRF-Token header). Payment-provider
# webhooks are exempt because they are authenticated by HMAC signature instead.
# ---------------------------------------------------------------------------
CSRF_EXEMPT_ENDPOINTS = {"payment_webhook"}


def csrf_token():
    if "_csrf" not in session:
        session["_csrf"] = secrets.token_hex(16)
    return session["_csrf"]


@app.before_request
def csrf_protect():
    if request.method in ("GET", "HEAD", "OPTIONS") or app.config.get("CSRF_DISABLED"):
        return
    if request.endpoint in CSRF_EXEMPT_ENDPOINTS:
        return
    sent = request.form.get("_csrf") or request.headers.get("X-CSRF-Token", "")
    if not sent or not hmac.compare_digest(sent, session.get("_csrf", "")):
        abort(400, "Your session expired or the form was invalid. Please go back, refresh the page and try again.")


@app.after_request
def security_headers(resp):
    resp.headers.setdefault("X-Content-Type-Options", "nosniff")
    resp.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
    resp.headers.setdefault("Referrer-Policy", "same-origin")
    return resp


# ---------------------------------------------------------------------------
# Helpers / auth
# ---------------------------------------------------------------------------

def get_db_conn():
    if "db" not in g:
        g.db = get_db()
    return g.db


@app.teardown_appcontext
def close_db(exception=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def login_required(*roles):
    def decorator(view):
        @functools.wraps(view)
        def wrapped(*args, **kwargs):
            if "user_id" not in session:
                return redirect(url_for("login"))
            row = get_db_conn().execute(
                "SELECT active, role, branch_id FROM users WHERE id = ?", (session["user_id"],)
            ).fetchone()
            if row is None or not row["active"]:
                session.clear()
                return redirect(url_for("login"))
            session["role"] = row["role"]        # pick up role/branch changes made by an admin
            session["branch_id"] = row["branch_id"]
            if roles and session.get("role") not in roles:
                abort(403)
            return view(*args, **kwargs)
        return wrapped
    return decorator


def current_user():
    if "user_id" not in session:
        return None
    return {
        "id": session["user_id"],
        "username": session["username"],
        "role": session["role"],
        "restaurant_id": session["restaurant_id"],
    }


def current_customer():
    if "customer_id" not in session:
        return None
    row = get_db_conn().execute("SELECT * FROM customers WHERE id = ?", (session["customer_id"],)).fetchone()
    if row is None:
        session.pop("customer_id", None)
        return None
    return row


def get_restaurant(restaurant_id):
    return get_db_conn().execute(
        "SELECT * FROM restaurants WHERE id = ?", (restaurant_id,)
    ).fetchone()


@app.context_processor
def inject_user():
    user = current_user()
    restaurant = get_restaurant(user["restaurant_id"]) if user else None
    return {"current_user": user, "restaurant": restaurant, "current_customer": current_customer(),
            "csrf_token": csrf_token()}


def get_table_or_404(qr_token):
    db = get_db_conn()
    table = db.execute(
        "SELECT * FROM tables_ WHERE qr_token = ?", (qr_token,)
    ).fetchone()
    if table is None or not table["active"]:
        abort(404)
    return table


def get_or_create_cart_order(db, restaurant_id, table):
    """A customer's 'cart' is an order row in status CART. One draft cart per table
    (a delivery customer gets their own disposable virtual table, so this still works)."""
    order = db.execute(
        "SELECT * FROM orders WHERE table_id = ? AND status = 'CART'",
        (table["id"],),
    ).fetchone()
    if order is None:
        order_type = "DELIVERY" if table["is_virtual"] else "DINE_IN"
        cur = db.execute(
            "INSERT INTO orders (restaurant_id, table_id, status, payment_status, branch_id, order_type) "
            "VALUES (?, ?, 'CART', 'PENDING', ?, ?)",
            (restaurant_id, table["id"], table["branch_id"], order_type),
        )
        db.commit()
        order = db.execute("SELECT * FROM orders WHERE id = ?", (cur.lastrowid,)).fetchone()
    # Attach the logged-in customer (if any) so loyalty applies even if they log in after adding items.
    cust = current_customer()
    if cust and order["customer_id"] != cust["id"]:
        db.execute("UPDATE orders SET customer_id = ? WHERE id = ?", (cust["id"], order["id"]))
        db.commit()
        order = db.execute("SELECT * FROM orders WHERE id = ?", (order["id"],)).fetchone()
    return order


def order_subtotal(db, order_id):
    return db.execute(
        "SELECT COALESCE(SUM(quantity * unit_price), 0) AS s FROM order_items WHERE order_id = ?",
        (order_id,),
    ).fetchone()["s"]


def promo_discount(promo, subtotal):
    amount = subtotal * promo["value"] / 100 if promo["kind"] == "PERCENT" else promo["value"]
    return round(min(amount, subtotal), 2)


def find_best_promotion(db, restaurant_id, subtotal, code=None):
    """Best single promotion for this subtotal: automatic ones (no code) always compete,
    code-based ones only if the customer entered that code. Returns (promo, discount) or None."""
    today = date.today().isoformat()
    rows = db.execute(
        "SELECT * FROM promotions WHERE restaurant_id = ? AND active = 1 AND min_order <= ? "
        "AND (starts_on IS NULL OR starts_on <= ?) AND (ends_on IS NULL OR ends_on >= ?) "
        "AND (max_uses IS NULL OR used_count < max_uses)",
        (restaurant_id, subtotal, today, today),
    ).fetchall()
    best = None
    for p in rows:
        if p["code"] and (not code or p["code"].upper() != code.upper()):
            continue
        d = promo_discount(p, subtotal)
        if d > 0 and (best is None or d > best[1]):
            best = (p, d)
    return best


def validate_code(db, restaurant_id, code, subtotal):
    """Returns (promo, None) if the code can be used now, else (None, reason)."""
    promo = db.execute(
        "SELECT * FROM promotions WHERE restaurant_id = ? AND UPPER(code) = UPPER(?)",
        (restaurant_id, code),
    ).fetchone()
    today = date.today().isoformat()
    if promo is None or not promo["active"]:
        return None, "That code isn't valid."
    if promo["starts_on"] and promo["starts_on"] > today:
        return None, "That promotion hasn't started yet."
    if promo["ends_on"] and promo["ends_on"] < today:
        return None, "That promotion has expired."
    if promo["max_uses"] is not None and promo["used_count"] >= promo["max_uses"]:
        return None, "That promotion has been fully used."
    if subtotal < promo["min_order"]:
        return None, f"This code needs a minimum order of ${promo['min_order']:.2f}."
    return promo, None


def recalc_order_total(db, order_id):
    order = db.execute(
        "SELECT restaurant_id, promo_code, loyalty_redeemed_value, delivery_fee FROM orders WHERE id = ?",
        (order_id,),
    ).fetchone()
    subtotal = order_subtotal(db, order_id)
    best = find_best_promotion(db, order["restaurant_id"], subtotal, order["promo_code"])
    promo_id, discount = (best[0]["id"], best[1]) if best else (None, 0.0)
    after_discount = round(subtotal - discount, 2)
    # A points redemption chosen earlier may no longer fit if the cart shrank; clamp it down.
    redeemed_value = round(min(order["loyalty_redeemed_value"] or 0, after_discount), 2)
    redeemed_points = int(round(redeemed_value / LOYALTY_POINT_VALUE)) if redeemed_value > 0 else 0
    total = round(after_discount - redeemed_value + (order["delivery_fee"] or 0), 2)
    db.execute(
        "UPDATE orders SET subtotal = ?, discount = ?, promotion_id = ?, "
        "loyalty_redeemed_value = ?, loyalty_points_redeemed = ?, total = ?, "
        "updated_at = CURRENT_TIMESTAMP WHERE id = ?",
        (subtotal, discount, promo_id, redeemed_value, redeemed_points, total, order_id),
    )
    # The cart changed after a payment was started: that payment no longer matches the order.
    db.execute("UPDATE payments SET status = 'VOIDED', note = 'Cart changed before payment' "
               "WHERE order_id = ? AND status = 'PENDING' AND ABS(amount - ?) > 0.004", (order_id, total))
    db.commit()
    return total


LOYALTY_POINTS_PER_DOLLAR = 1     # points earned per $1 of the final total
LOYALTY_POINT_VALUE = 0.01        # $ redeemed per point (100 points = $1)


def loyalty_ledger(db, customer_id, order_id, change, reason):
    db.execute("INSERT INTO loyalty_transactions (customer_id, order_id, change, reason) VALUES (?, ?, ?, ?)",
               (customer_id, order_id, change, reason))
    db.execute("UPDATE customers SET loyalty_points = loyalty_points + ? WHERE id = ?", (change, customer_id))


def max_redeemable_points(customer, amount_owed):
    """Can't redeem more points than the customer has, or more value than is left to pay."""
    by_balance = customer["loyalty_points"] if customer else 0
    by_amount = int(amount_owed / LOYALTY_POINT_VALUE)
    return max(0, min(by_balance, by_amount))


def can_fulfill(db, menu_item_id, wanted_qty):
    """True if every tracked ingredient has enough stock for wanted_qty portions."""
    rows = db.execute(
        "SELECT r.quantity AS need, inv.quantity AS have FROM menu_item_ingredients r "
        "JOIN inventory_items inv ON inv.id = r.inventory_item_id "
        "WHERE r.menu_item_id = ? AND inv.active = 1",
        (menu_item_id,),
    ).fetchall()
    return all(row["have"] + 1e-9 >= row["need"] * wanted_qty for row in rows)


def out_of_stock_item_ids(db, restaurant_id):
    rows = db.execute(
        "SELECT DISTINCT mi.id FROM menu_items mi "
        "JOIN menu_item_ingredients r ON r.menu_item_id = mi.id "
        "JOIN inventory_items inv ON inv.id = r.inventory_item_id "
        "WHERE mi.restaurant_id = ? AND inv.active = 1 AND inv.quantity + 1e-9 < r.quantity",
        (restaurant_id,),
    ).fetchall()
    return {r["id"] for r in rows}


def deduct_stock_for_order(db, order_id, user_id):
    """Uses up ingredients for an order (stock never goes below zero) and logs each movement."""
    order = db.execute("SELECT restaurant_id FROM orders WHERE id = ?", (order_id,)).fetchone()
    lines = db.execute("SELECT menu_item_id, quantity FROM order_items WHERE order_id = ?", (order_id,)).fetchall()
    for line in lines:
        recipe = db.execute(
            "SELECT r.inventory_item_id, r.quantity AS per_portion, inv.quantity AS have "
            "FROM menu_item_ingredients r JOIN inventory_items inv ON inv.id = r.inventory_item_id "
            "WHERE r.menu_item_id = ? AND inv.active = 1",
            (line["menu_item_id"],),
        ).fetchall()
        for ing in recipe:
            have = db.execute("SELECT quantity FROM inventory_items WHERE id = ?",
                              (ing["inventory_item_id"],)).fetchone()["quantity"]
            used = min(have, ing["per_portion"] * line["quantity"])
            if used <= 0:
                continue
            db.execute("UPDATE inventory_items SET quantity = quantity - ? WHERE id = ?",
                       (used, ing["inventory_item_id"]))
            db.execute(
                "INSERT INTO stock_movements (restaurant_id, inventory_item_id, change, reason, user_id) "
                "VALUES (?, ?, ?, ?, ?)",
                (order["restaurant_id"], ing["inventory_item_id"], -used, f"Order #{order_id}", user_id),
            )


def log_order_event(db, order_id, user_id, action):
    db.execute("INSERT INTO order_events (order_id, user_id, action) VALUES (?, ?, ?)",
               (order_id, user_id, action))


@app.template_filter("mins")
def mins_filter(value):
    return "—" if value is None else f"{value:.1f} min"


@app.template_filter("num")
def num_filter(value):
    return f"{value:g}"


# ---------------------------------------------------------------------------
# Auth routes
# ---------------------------------------------------------------------------

@app.route("/")
def index():
    if current_user():
        return redirect(url_for(f"{session['role']}_dashboard"))
    return redirect(url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        db = get_db_conn()
        user = db.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
        if user is None or not check_password_hash(user["password_hash"], password):
            return render_template("login.html", error="Invalid username or password")
        if not user["active"]:
            return render_template("login.html", error="This account is inactive. Contact your admin.")
        session["user_id"] = user["id"]
        session["username"] = user["username"]
        session["role"] = user["role"]
        session["restaurant_id"] = user["restaurant_id"]
        return redirect(url_for(f"{user['role']}_dashboard"))
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# ---------------------------------------------------------------------------
# Customer flow (no login -- identified by table QR token)
# ---------------------------------------------------------------------------

DELIVERY_FEE = 2.00


@app.route("/t/<qr_token>")
def customer_menu(qr_token):
    db = get_db_conn()
    table = get_table_or_404(qr_token)
    rid = table["restaurant_id"]
    categories = db.execute(
        "SELECT * FROM categories WHERE restaurant_id = ? AND active = 1 ORDER BY sort_order, id", (rid,)
    ).fetchall()
    items = db.execute("SELECT * FROM menu_items WHERE restaurant_id = ? AND available = 1", (rid,)).fetchall()
    cart_order = get_or_create_cart_order(db, rid, table)
    recalc_order_total(db, cart_order["id"])  # keeps promotions/prices/points current
    cart_order = db.execute("SELECT * FROM orders WHERE id = ?", (cart_order["id"],)).fetchone()
    cart_items = db.execute(
        "SELECT oi.*, mi.name FROM order_items oi JOIN menu_items mi ON mi.id = oi.menu_item_id "
        "WHERE oi.order_id = ?",
        (cart_order["id"],),
    ).fetchall()
    promo = None
    if cart_order["promotion_id"]:
        promo = db.execute("SELECT * FROM promotions WHERE id = ?", (cart_order["promotion_id"],)).fetchone()
    after_discount = round(cart_order["subtotal"] - cart_order["discount"], 2)
    customer = current_customer()
    return render_template(
        "customer_menu.html",
        restaurant=get_restaurant(rid),
        table=table,
        categories=categories,
        items=items,
        out_of_stock=out_of_stock_item_ids(db, rid),
        cart_items=cart_items,
        cart=cart_order,
        promo=promo,
        customer=customer,
        max_redeemable=max_redeemable_points(customer, after_discount) if customer else 0,
        point_value=LOYALTY_POINT_VALUE,
    )


@app.route("/t/<qr_token>/cart/add", methods=["POST"])
def customer_add_to_cart(qr_token):
    db = get_db_conn()
    table = get_table_or_404(qr_token)
    item_id = request.form.get("item_id", type=int)
    qty = request.form.get("qty", default=1, type=int)
    item = db.execute(
        "SELECT mi.* FROM menu_items mi LEFT JOIN categories c ON c.id = mi.category_id "
        "WHERE mi.id = ? AND mi.restaurant_id = ? AND mi.available = 1 "
        "AND (c.id IS NULL OR c.active = 1)",
        (item_id, table["restaurant_id"]),
    ).fetchone()
    if item is None:
        abort(404)
    qty = max(1, min(qty or 1, 50))
    cart_order = get_or_create_cart_order(db, table["restaurant_id"], table)
    existing = db.execute(
        "SELECT * FROM order_items WHERE order_id = ? AND menu_item_id = ?",
        (cart_order["id"], item_id),
    ).fetchone()
    wanted = (existing["quantity"] if existing else 0) + qty
    if not can_fulfill(db, item_id, wanted):
        flash(f"Sorry, we don't have enough stock of {item['name']}.")
        return redirect(url_for("customer_menu", qr_token=qr_token))
    if existing:
        db.execute("UPDATE order_items SET quantity = quantity + ? WHERE id = ?", (qty, existing["id"]))
    else:
        db.execute(
            "INSERT INTO order_items (order_id, menu_item_id, quantity, unit_price) VALUES (?, ?, ?, ?)",
            (cart_order["id"], item_id, qty, item["price"]),
        )
    recalc_order_total(db, cart_order["id"])
    return redirect(url_for("customer_menu", qr_token=qr_token))


@app.route("/t/<qr_token>/cart/remove", methods=["POST"])
def customer_remove_from_cart(qr_token):
    db = get_db_conn()
    table = get_table_or_404(qr_token)
    order_item_id = request.form.get("order_item_id", type=int)
    cart_order = get_or_create_cart_order(db, table["restaurant_id"], table)
    db.execute("DELETE FROM order_items WHERE id = ? AND order_id = ?", (order_item_id, cart_order["id"]))
    recalc_order_total(db, cart_order["id"])
    return redirect(url_for("customer_menu", qr_token=qr_token))


PAYMENT_EXPIRY_MINUTES = 30


def public_base_url():
    """Base URL printed into QR codes and sent to payment providers. Set NEXORA_PUBLIC_URL in production."""
    return (os.environ.get("NEXORA_PUBLIC_URL") or request.host_url).rstrip("/")


def finalize_paid_order(db, order_id):
    """Runs exactly once per order, after money is confirmed: claims the promotion and loyalty
    points, moves the order to NEW (cashier queue), awards points, notifies accounting."""
    order = db.execute("SELECT * FROM orders WHERE id = ?", (order_id,)).fetchone()
    if order is None or order["status"] != "CART":
        return False
    if order["promotion_id"]:
        db.execute("UPDATE promotions SET used_count = used_count + 1 WHERE id = ?", (order["promotion_id"],))
    if order["loyalty_points_redeemed"] and order["customer_id"]:
        customer = db.execute("SELECT loyalty_points FROM customers WHERE id = ?", (order["customer_id"],)).fetchone()
        spend = min(order["loyalty_points_redeemed"], customer["loyalty_points"] if customer else 0)
        if spend:
            loyalty_ledger(db, order["customer_id"], order_id, -spend, "REDEEM")
    db.execute("UPDATE orders SET status = 'NEW', payment_status = 'PAID', placed_at = CURRENT_TIMESTAMP, "
               "updated_at = CURRENT_TIMESTAMP WHERE id = ?", (order_id,))
    db.commit()
    if order["customer_id"]:
        food_value = round(order["subtotal"] - order["discount"] - order["loyalty_redeemed_value"], 2)
        earned = max(0, int(food_value * LOYALTY_POINTS_PER_DOLLAR))
        if earned:
            loyalty_ledger(db, order["customer_id"], order_id, earned, "EARN")
        db.execute("UPDATE orders SET loyalty_points_earned = ? WHERE id = ?", (earned, order_id))
        db.commit()
    send_accounting_webhook(db, order["restaurant_id"], order_id, "order.paid")
    return True


def settle_payment(db, payment, outcome, provider_ref=""):
    """Applies a provider result. Safe to call any number of times (double clicks, refreshes,
    repeated webhooks): only the first PAID result can finalize the order."""
    if outcome == "FAILED":
        db.execute("UPDATE payments SET status = 'FAILED', completed_at = CURRENT_TIMESTAMP, "
                   "note = 'Payment was not completed' WHERE id = ? AND status = 'PENDING'", (payment["id"],))
        db.commit()
        return
    if outcome != "PAID":
        return
    current = db.execute("SELECT status FROM payments WHERE id = ?", (payment["id"],)).fetchone()["status"]
    if current not in ("PENDING", "FAILED", "VOIDED"):
        return  # already PAID / refunded -- nothing to do
    order = db.execute("SELECT status, total FROM orders WHERE id = ?", (payment["order_id"],)).fetchone()
    if order and order["status"] == "CART" and abs(order["total"] - payment["amount"]) < 0.005:
        won = db.execute("UPDATE payments SET status = 'PAID', completed_at = CURRENT_TIMESTAMP, note = '', "
                         "provider_ref = COALESCE(NULLIF(?, ''), provider_ref) WHERE id = ? "
                         "AND status IN ('PENDING', 'FAILED', 'VOIDED')", (provider_ref, payment["id"])).rowcount
        db.commit()
        if won:
            finalize_paid_order(db, payment["order_id"])
    else:  # money arrived but the order can't use it (cart changed, or already paid) -> flag for refund
        db.execute("UPDATE payments SET status = 'REFUND_DUE', completed_at = CURRENT_TIMESTAMP, "
                   "note = 'Paid, but the order was changed, cancelled or already paid' WHERE id = ?", (payment["id"],))
        db.commit()


@app.route("/t/<qr_token>/checkout", methods=["POST"])
def customer_checkout(qr_token):
    """Validates the cart, then starts (or resumes) a payment. The order only reaches the
    cashier once the payment is confirmed -- until then it stays a CART with PENDING payment."""
    db = get_db_conn()
    table = get_table_or_404(qr_token)
    cart_order = get_or_create_cart_order(db, table["restaurant_id"], table)
    item_count = db.execute(
        "SELECT COUNT(*) AS c FROM order_items WHERE order_id = ?", (cart_order["id"],)
    ).fetchone()["c"]
    if item_count == 0:
        return redirect(url_for("customer_menu", qr_token=qr_token))
    phone = request.form.get("phone", "").strip()
    if table["is_virtual"]:  # delivery order -- an address is required
        address = request.form.get("address", "").strip()
        if not address or not phone:
            flash("Please enter a delivery address and phone number.")
            return redirect(url_for("customer_menu", qr_token=qr_token))
        db.execute("UPDATE orders SET delivery_address = ?, delivery_phone = ? WHERE id = ?",
                   (address, phone, cart_order["id"]))
        db.commit()
    for line in db.execute("SELECT menu_item_id, quantity FROM order_items WHERE order_id = ?",
                           (cart_order["id"],)).fetchall():
        if not can_fulfill(db, line["menu_item_id"], line["quantity"]):
            flash("Some items in your cart just ran out of stock. Please adjust your order.")
            return redirect(url_for("customer_menu", qr_token=qr_token))
    recalc_order_total(db, cart_order["id"])
    fresh = db.execute(
        "SELECT customer_id, loyalty_points_redeemed, total FROM orders WHERE id = ?", (cart_order["id"],)
    ).fetchone()
    if fresh["loyalty_points_redeemed"]:
        customer = db.execute("SELECT * FROM customers WHERE id = ?", (fresh["customer_id"],)).fetchone()
        if customer is None or customer["loyalty_points"] < fresh["loyalty_points_redeemed"]:
            # Points were spent elsewhere in the meantime -- drop the redemption and recalculate.
            db.execute("UPDATE orders SET loyalty_points_redeemed = 0, loyalty_redeemed_value = 0 WHERE id = ?",
                       (cart_order["id"],))
            db.commit()
            recalc_order_total(db, cart_order["id"])
            flash("Your points balance changed, so the redemption was removed. Your total was updated.")
            return redirect(url_for("customer_menu", qr_token=qr_token))
    total = fresh["total"]
    restaurant = get_restaurant(table["restaurant_id"])
    # Duplicate-payment protection: resume the open payment for this exact amount instead of making another.
    payment = db.execute(
        "SELECT * FROM payments WHERE order_id = ? AND status = 'PENDING' AND ABS(amount - ?) < 0.005 "
        "ORDER BY id DESC LIMIT 1", (cart_order["id"], total)).fetchone()
    if payment is None:
        txn_id = "TXN-" + secrets.token_hex(6).upper()
        provider = "NONE" if total <= 0 else restaurant["payment_provider"]
        db.execute("INSERT INTO payments (restaurant_id, order_id, transaction_id, provider, amount) "
                   "VALUES (?, ?, ?, ?, ?)", (table["restaurant_id"], cart_order["id"], txn_id, provider, total))
        db.commit()
        payment = db.execute("SELECT * FROM payments WHERE transaction_id = ?", (txn_id,)).fetchone()
        if provider == "NONE":  # fully covered by discounts / points -- nothing to charge
            settle_payment(db, payment, "PAID")
            return redirect(url_for("customer_order_status", qr_token=qr_token, order_id=cart_order["id"]))
        try:
            ref, checkout_url = payments.initiate(
                provider, txn_id, total, phone,
                public_base_url() + url_for("payment_webhook"),
                public_base_url() + url_for("customer_payment", qr_token=qr_token, txn_id=txn_id))
        except payments.PaymentError as e:
            settle_payment(db, payment, "FAILED")
            flash(f"{e} Please try again.")
            return redirect(url_for("customer_menu", qr_token=qr_token))
        db.execute("UPDATE payments SET provider_ref = ?, checkout_url = ? WHERE id = ?",
                   (ref, checkout_url, payment["id"]))
        db.commit()
    return redirect(url_for("customer_payment", qr_token=qr_token, txn_id=payment["transaction_id"]))


def get_customer_payment(db, table, txn_id):
    payment = db.execute(
        "SELECT p.* FROM payments p JOIN orders o ON o.id = p.order_id "
        "WHERE p.transaction_id = ? AND o.table_id = ?", (txn_id, table["id"])).fetchone()
    if payment is None:
        abort(404)
    if payment["status"] == "PENDING":
        age = db.execute("SELECT (julianday('now') - julianday(created_at)) * 1440 AS m FROM payments WHERE id = ?",
                         (payment["id"],)).fetchone()["m"]
        if age > PAYMENT_EXPIRY_MINUTES:
            settle_payment(db, payment, "FAILED")
            payment = db.execute("SELECT * FROM payments WHERE id = ?", (payment["id"],)).fetchone()
    return payment


@app.route("/t/<qr_token>/pay/<txn_id>")
def customer_payment(qr_token, txn_id):
    db = get_db_conn()
    table = get_table_or_404(qr_token)
    payment = get_customer_payment(db, table, txn_id)
    if payment["status"] == "PAID":
        return redirect(url_for("customer_order_status", qr_token=qr_token, order_id=payment["order_id"]))
    order = db.execute("SELECT * FROM orders WHERE id = ?", (payment["order_id"],)).fetchone()
    return render_template("customer_payment.html", restaurant=get_restaurant(table["restaurant_id"]),
                           table=table, payment=payment, order=order)


@app.route("/t/<qr_token>/pay/<txn_id>/status")
def customer_payment_status(qr_token, txn_id):
    table = get_table_or_404(qr_token)
    payment = get_customer_payment(get_db_conn(), table, txn_id)
    return jsonify(status=payment["status"])


@app.route("/t/<qr_token>/pay/<txn_id>/simulate", methods=["POST"])
def customer_payment_simulate(qr_token, txn_id):
    """Demo gateway buttons. Refused outright unless the payment was created by the SIMULATED provider."""
    db = get_db_conn()
    table = get_table_or_404(qr_token)
    payment = get_customer_payment(db, table, txn_id)
    if payment["provider"] != "SIMULATED":
        abort(403)
    settle_payment(db, payment, "PAID" if request.form.get("result") == "approve" else "FAILED")
    return redirect(url_for("customer_payment", qr_token=qr_token, txn_id=txn_id))


@app.route("/t/<qr_token>/pay/<txn_id>/cancel", methods=["POST"])
def customer_payment_cancel(qr_token, txn_id):
    db = get_db_conn()
    table = get_table_or_404(qr_token)
    payment = get_customer_payment(db, table, txn_id)
    if payment["status"] == "PENDING" and payment["provider"] == "SIMULATED":
        settle_payment(db, payment, "FAILED")
    elif payment["status"] == "PENDING":  # a real provider may still confirm later; just leave the page
        db.execute("UPDATE payments SET note = 'Customer left the payment page' WHERE id = ?", (payment["id"],))
        db.commit()
    return redirect(url_for("customer_menu", qr_token=qr_token))


@app.route("/webhooks/payments", methods=["POST"])
def payment_webhook():
    """Provider -> Nexora confirmation. Signed with HMAC-SHA256 of the raw body
    (header X-Nexora-Signature). Idempotent: repeated deliveries are harmless."""
    body = request.get_data()
    sig = request.headers.get("X-Nexora-Signature") or request.headers.get("X-Signature", "")
    if not payments.verify_signature(body, sig):
        abort(401)
    try:
        txn_id, outcome, ref, amount = payments.parse_webhook(json.loads(body))
    except (ValueError, TypeError):
        abort(400)
    db = get_db_conn()
    payment = db.execute("SELECT * FROM payments WHERE transaction_id = ?", (txn_id,)).fetchone()
    if payment is None:
        abort(404)
    if amount is not None and abs(amount - payment["amount"]) > 0.005:
        db.execute("UPDATE payments SET note = ? WHERE id = ?",
                   (f"Webhook amount mismatch ({amount} vs {payment['amount']}) -- ignored", payment["id"]))
        db.commit()
        abort(400)
    settle_payment(db, payment, outcome, ref)
    return jsonify(ok=True)


@app.route("/t/<qr_token>/order/<int:order_id>")
def customer_order_status(qr_token, order_id):
    db = get_db_conn()
    table = get_table_or_404(qr_token)
    order = db.execute(
        "SELECT * FROM orders WHERE id = ? AND table_id = ?", (order_id, table["id"])
    ).fetchone()
    if order is None:
        abort(404)
    order_items = db.execute(
        "SELECT oi.*, mi.name FROM order_items oi JOIN menu_items mi ON mi.id = oi.menu_item_id "
        "WHERE oi.order_id = ?",
        (order_id,),
    ).fetchall()
    promo = None
    if order["promotion_id"]:
        promo = db.execute("SELECT * FROM promotions WHERE id = ?", (order["promotion_id"],)).fetchone()
    feedback = db.execute("SELECT * FROM feedback WHERE order_id = ?", (order_id,)).fetchone()
    return render_template(
        "customer_order_status.html", restaurant=get_restaurant(table["restaurant_id"]), table=table,
        order=order, order_items=order_items, promo=promo, feedback=feedback,
        can_review=order["status"] in ("READY", "SERVED", "COMPLETED") and feedback is None,
    )


@app.route("/t/<qr_token>/redeem", methods=["POST"])
def customer_redeem_points(qr_token):
    db = get_db_conn()
    table = get_table_or_404(qr_token)
    customer = current_customer()
    cart_order = get_or_create_cart_order(db, table["restaurant_id"], table)
    if request.form.get("action") == "remove" or not customer:
        db.execute("UPDATE orders SET loyalty_points_redeemed = 0, loyalty_redeemed_value = 0 WHERE id = ?",
                   (cart_order["id"],))
    else:
        points = request.form.get("points", type=int, default=0)
        after_discount = round(cart_order["subtotal"] - cart_order["discount"], 2)
        cap = max_redeemable_points(customer, after_discount)
        if points <= 0:
            flash("Enter how many points you'd like to use.")
        else:
            points = min(points, cap)
            db.execute("UPDATE orders SET loyalty_points_redeemed = ?, loyalty_redeemed_value = ? WHERE id = ?",
                       (points, round(points * LOYALTY_POINT_VALUE, 2), cart_order["id"]))
    db.commit()
    recalc_order_total(db, cart_order["id"])
    return redirect(url_for("customer_menu", qr_token=qr_token))


@app.route("/t/<qr_token>/account/register", methods=["GET", "POST"])
def customer_register(qr_token):
    db = get_db_conn()
    table = get_table_or_404(qr_token)
    error = None
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        phone = request.form.get("phone", "").strip()
        pin = request.form.get("pin", "")
        if not name or not phone:
            error = "Please enter your name and phone number."
        elif not (pin.isdigit() and 4 <= len(pin) <= 6):
            error = "Choose a 4-6 digit PIN."
        elif db.execute("SELECT 1 FROM customers WHERE restaurant_id = ? AND phone = ?",
                        (table["restaurant_id"], phone)).fetchone():
            error = "That phone number already has an account -- try logging in instead."
        else:
            cur = db.execute(
                "INSERT INTO customers (restaurant_id, name, phone, pin_hash) VALUES (?, ?, ?, ?)",
                (table["restaurant_id"], name, phone, generate_password_hash(pin)),
            )
            db.commit()
            session["customer_id"] = cur.lastrowid
            return redirect(url_for("customer_menu", qr_token=qr_token))
    return render_template("customer_account.html", table=table, restaurant=get_restaurant(table["restaurant_id"]),
                           mode="register", error=error)


@app.route("/t/<qr_token>/account/login", methods=["GET", "POST"])
def customer_login(qr_token):
    db = get_db_conn()
    table = get_table_or_404(qr_token)
    error = None
    if request.method == "POST":
        phone = request.form.get("phone", "").strip()
        pin = request.form.get("pin", "")
        cust = db.execute("SELECT * FROM customers WHERE restaurant_id = ? AND phone = ?",
                          (table["restaurant_id"], phone)).fetchone()
        if cust is None or not check_password_hash(cust["pin_hash"], pin):
            error = "Phone number or PIN not recognized."
        else:
            session["customer_id"] = cust["id"]
            return redirect(url_for("customer_menu", qr_token=qr_token))
    return render_template("customer_account.html", table=table, restaurant=get_restaurant(table["restaurant_id"]),
                           mode="login", error=error)


@app.route("/t/<qr_token>/account/logout")
def customer_logout(qr_token):
    session.pop("customer_id", None)
    return redirect(url_for("customer_menu", qr_token=qr_token))


@app.route("/t/<qr_token>/promo", methods=["POST"])
def customer_apply_promo(qr_token):
    db = get_db_conn()
    table = get_table_or_404(qr_token)
    cart_order = get_or_create_cart_order(db, table["restaurant_id"], table)
    if request.form.get("action") == "remove":
        db.execute("UPDATE orders SET promo_code = NULL WHERE id = ?", (cart_order["id"],))
        db.commit()
        recalc_order_total(db, cart_order["id"])
    else:
        code = request.form.get("code", "").strip()
        subtotal = order_subtotal(db, cart_order["id"])
        promo, error = validate_code(db, table["restaurant_id"], code, subtotal) if code else (None, "Enter a code.")
        if error:
            flash(error)
        else:
            db.execute("UPDATE orders SET promo_code = ? WHERE id = ?", (promo["code"], cart_order["id"]))
            db.commit()
            recalc_order_total(db, cart_order["id"])
            flash(f"Applied: {promo['name']}")
    return redirect(url_for("customer_menu", qr_token=qr_token))


@app.route("/t/<qr_token>/order/<int:order_id>/feedback", methods=["POST"])
def customer_feedback(qr_token, order_id):
    db = get_db_conn()
    table = get_table_or_404(qr_token)
    order = db.execute("SELECT * FROM orders WHERE id = ? AND table_id = ?", (order_id, table["id"])).fetchone()
    if order is None:
        abort(404)
    rating = request.form.get("rating", type=int)
    if order["status"] not in ("READY", "SERVED", "COMPLETED"):
        flash("You can leave feedback once your order is ready.")
    elif rating is None or not 1 <= rating <= 5:
        flash("Please choose a rating from 1 to 5.")
    elif db.execute("SELECT 1 FROM feedback WHERE order_id = ?", (order_id,)).fetchone():
        flash("Thanks - feedback was already submitted for this order.")
    else:
        db.execute(
            "INSERT INTO feedback (restaurant_id, order_id, table_id, rating, comment) VALUES (?, ?, ?, ?, ?)",
            (table["restaurant_id"], order_id, table["id"], rating, request.form.get("comment", "").strip()[:500]),
        )
        db.commit()
        flash("Thank you for your feedback!")
    return redirect(url_for("customer_order_status", qr_token=qr_token, order_id=order_id))


@app.route("/t/<qr_token>/service-request", methods=["POST"])
def customer_service_request(qr_token):
    db = get_db_conn()
    table = get_table_or_404(qr_token)
    kind = request.form.get("kind")
    message = request.form.get("message", "")
    if kind not in ("CALL_WAITER", "REQUEST_BILL", "REQUEST_WATER", "ASSISTANCE", "CUSTOM"):
        abort(400)
    db.execute(
        "INSERT INTO service_requests (restaurant_id, table_id, kind, message) VALUES (?, ?, ?, ?)",
        (table["restaurant_id"], table["id"], kind, message),
    )
    db.commit()
    return redirect(url_for("customer_menu", qr_token=qr_token))


# ---------------------------------------------------------------------------
# Public restaurant page -- delivery ordering + table reservations
# (no login/table QR required; found via /r/<restaurant_id>)
# ---------------------------------------------------------------------------

def get_restaurant_or_404(restaurant_id):
    r = get_db_conn().execute("SELECT * FROM restaurants WHERE id = ?", (restaurant_id,)).fetchone()
    if r is None:
        abort(404)
    return r


@app.route("/r/<int:restaurant_id>")
def restaurant_landing(restaurant_id):
    restaurant = get_restaurant_or_404(restaurant_id)
    db = get_db_conn()
    branches = db.execute("SELECT * FROM branches WHERE restaurant_id = ? AND active = 1 ORDER BY name",
                          (restaurant_id,)).fetchall()
    return render_template("restaurant_landing.html", restaurant=restaurant, branches=branches)


@app.route("/r/<int:restaurant_id>/delivery", methods=["GET", "POST"])
def start_delivery_order(restaurant_id):
    """Creates a disposable 'virtual table' for this delivery order and hands off to the
    normal customer ordering flow, so cart/checkout/status all work exactly as dine-in does."""
    restaurant = get_restaurant_or_404(restaurant_id)
    db = get_db_conn()
    branches = db.execute("SELECT * FROM branches WHERE restaurant_id = ? AND active = 1 ORDER BY name",
                          (restaurant_id,)).fetchall()
    if request.method == "POST" or not branches:
        branch_id = request.form.get("branch_id", type=int) if branches else None
        if branches and not any(b["id"] == branch_id for b in branches):
            flash("Please choose a branch.")
            return redirect(url_for("start_delivery_order", restaurant_id=restaurant_id))
        token = secrets.token_urlsafe(8)
        db.execute(
            "INSERT INTO tables_ (restaurant_id, number, qr_token, branch_id, is_virtual) "
            "VALUES (?, 'Delivery', ?, ?, 1)",
            (restaurant_id, token, branch_id),
        )
        db.commit()
        # A fresh virtual table's cart needs the delivery fee set once, up front.
        table = db.execute("SELECT * FROM tables_ WHERE qr_token = ?", (token,)).fetchone()
        cart = get_or_create_cart_order(db, restaurant_id, table)
        db.execute("UPDATE orders SET delivery_fee = ? WHERE id = ?", (DELIVERY_FEE, cart["id"]))
        db.commit()
        return redirect(url_for("customer_menu", qr_token=token))
    return render_template("start_delivery.html", restaurant=restaurant, branches=branches)


@app.route("/r/<int:restaurant_id>/reserve", methods=["GET", "POST"])
def make_reservation(restaurant_id):
    restaurant = get_restaurant_or_404(restaurant_id)
    db = get_db_conn()
    branches = db.execute("SELECT * FROM branches WHERE restaurant_id = ? AND active = 1 ORDER BY name",
                          (restaurant_id,)).fetchall()
    error = None
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        phone = request.form.get("phone", "").strip()
        party_size = request.form.get("party_size", type=int)
        when = request.form.get("when", "").strip()  # "YYYY-MM-DDTHH:MM" from <input type=datetime-local>
        branch_id = request.form.get("branch_id", type=int) if branches else None
        notes = request.form.get("notes", "").strip()[:500]
        try:
            when_dt = datetime.fromisoformat(when)
            valid_time = when_dt > datetime.now()
        except ValueError:
            valid_time = False
        if not name or not phone:
            error = "Please enter your name and phone number."
        elif not party_size or party_size < 1:
            error = "Party size must be at least 1."
        elif not valid_time:
            error = "Please choose a date and time in the future."
        elif branches and not any(b["id"] == branch_id for b in branches):
            error = "Please choose a branch."
        else:
            db.execute(
                "INSERT INTO reservations (restaurant_id, branch_id, guest_name, guest_phone, party_size, "
                "reservation_time, notes) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (restaurant_id, branch_id, name, phone, party_size, when_dt.strftime("%Y-%m-%d %H:%M:%S"), notes),
            )
            db.commit()
            return render_template("reservation_done.html", restaurant=restaurant)
    return render_template("make_reservation.html", restaurant=restaurant, branches=branches, error=error)


# ---------------------------------------------------------------------------
# Admin dashboard
# ---------------------------------------------------------------------------

@app.route("/admin")
@login_required("admin")
def admin_dashboard():
    db = get_db_conn()
    rid = session["restaurant_id"]
    stats = db.execute(
        "SELECT COUNT(*) AS order_count, COALESCE(SUM(total), 0) AS revenue FROM orders "
        "WHERE restaurant_id = ? AND payment_status = 'PAID' AND status != 'CANCELLED'",
        (rid,),
    ).fetchone()
    counts = db.execute(
        "SELECT "
        "(SELECT COUNT(*) FROM menu_items WHERE restaurant_id = :r AND available = 1) AS items_active, "
        "(SELECT COUNT(*) FROM menu_items WHERE restaurant_id = :r AND available = 0) AS items_inactive, "
        "(SELECT COUNT(*) FROM tables_ WHERE restaurant_id = :r AND active = 1) AS tables_active, "
        "(SELECT COUNT(*) FROM users WHERE restaurant_id = :r AND active = 1) AS staff_active, "
        "(SELECT COUNT(*) FROM inventory_items WHERE restaurant_id = :r AND active = 1 "
        " AND quantity <= low_stock_threshold) AS low_stock, "
        "(SELECT ROUND(AVG(rating), 1) FROM feedback WHERE restaurant_id = :r) AS avg_rating, "
        "(SELECT COUNT(*) FROM feedback WHERE restaurant_id = :r) AS feedback_count, "
        "(SELECT COUNT(*) FROM branches WHERE restaurant_id = :r AND active = 1) AS branches_active, "
        "(SELECT COUNT(*) FROM customers WHERE restaurant_id = :r) AS customer_count, "
        "(SELECT COUNT(*) FROM reservations WHERE restaurant_id = :r AND status IN ('REQUESTED','CONFIRMED')) "
        " AS reservations_pending",
        {"r": rid},
    ).fetchone()
    recent_orders = db.execute(
        "SELECT o.*, t.number AS table_number FROM orders o JOIN tables_ t ON t.id = o.table_id "
        "WHERE o.restaurant_id = ? AND o.status != 'CART' ORDER BY o.created_at DESC LIMIT 10",
        (rid,),
    ).fetchall()
    return render_template("admin_dashboard.html", stats=stats, counts=counts, recent_orders=recent_orders,
                           delivery_link=url_for("restaurant_landing", restaurant_id=rid, _external=False),
                           can=lambda perm: perm not in revoked_perms_for(session["user_id"]))


@app.route("/admin/settings", methods=["GET", "POST"])
@login_required("admin")
@require_perm("settings.manage")
def admin_settings():
    db = get_db_conn()
    rid = session["restaurant_id"]
    error = None
    saved = request.args.get("saved")
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        if not name:
            error = "The restaurant / hotel name is required."
        else:
            db.execute(
                "UPDATE restaurants SET name = ?, address = ?, phone = ? WHERE id = ?",
                (name, request.form.get("address", "").strip(), request.form.get("phone", "").strip(), rid),
            )
            log_admin_action(db, "settings.update", f"name={name}")
            db.commit()
            return redirect(url_for("admin_settings", saved=1))
    return render_template("admin_settings.html", error=error, saved=saved)


@app.route("/admin/menu", methods=["GET", "POST"])
@login_required("admin")
@require_perm("menu.manage")
def admin_menu():
    db = get_db_conn()
    rid = session["restaurant_id"]
    if request.method == "POST":
        action = request.form.get("action")
        if action == "add_category":
            name = request.form.get("name", "").strip()
            if name:
                db.execute("INSERT INTO categories (restaurant_id, name) VALUES (?, ?)", (rid, name))
        elif action == "rename_category":
            name = request.form.get("name", "").strip()
            if name:
                db.execute("UPDATE categories SET name = ? WHERE id = ? AND restaurant_id = ?",
                           (name, request.form.get("category_id", type=int), rid))
        elif action == "toggle_category":
            db.execute("UPDATE categories SET active = 1 - active WHERE id = ? AND restaurant_id = ?",
                       (request.form.get("category_id", type=int), rid))
        elif action == "add_item":
            price = request.form.get("price", type=float)
            name = request.form.get("name", "").strip()
            if name and price is not None and price >= 0:
                db.execute(
                    "INSERT INTO menu_items (restaurant_id, category_id, name, description, price) "
                    "VALUES (?, ?, ?, ?, ?)",
                    (rid, request.form.get("category_id", type=int), name,
                     request.form.get("description", "").strip(), price),
                )
        elif action == "toggle_available":
            db.execute(
                "UPDATE menu_items SET available = 1 - available WHERE id = ? AND restaurant_id = ?",
                (request.form.get("item_id", type=int), rid),
            )
        elif action == "delete_item":
            item_id = request.form.get("item_id", type=int)
            used = db.execute("SELECT 1 FROM order_items WHERE menu_item_id = ? LIMIT 1", (item_id,)).fetchone()
            if used:
                # Past orders reference this item, so keep it and just make it inactive.
                db.execute("UPDATE menu_items SET available = 0 WHERE id = ? AND restaurant_id = ?",
                           (item_id, rid))
            else:
                db.execute("DELETE FROM menu_items WHERE id = ? AND restaurant_id = ?", (item_id, rid))
        db.commit()
        return redirect(url_for("admin_menu"))

    categories = db.execute(
        "SELECT * FROM categories WHERE restaurant_id = ? ORDER BY sort_order, id", (rid,)
    ).fetchall()
    items = db.execute(
        "SELECT mi.*, c.name AS category_name FROM menu_items mi "
        "LEFT JOIN categories c ON c.id = mi.category_id WHERE mi.restaurant_id = ? ORDER BY mi.id",
        (rid,),
    ).fetchall()
    return render_template("admin_menu.html", categories=categories, items=items)


@app.route("/admin/menu/item/<int:item_id>/edit", methods=["GET", "POST"])
@login_required("admin")
@require_perm("menu.manage")
def admin_item_edit(item_id):
    db = get_db_conn()
    rid = session["restaurant_id"]
    item = db.execute("SELECT * FROM menu_items WHERE id = ? AND restaurant_id = ?", (item_id, rid)).fetchone()
    if item is None:
        abort(404)
    error = None
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        price = request.form.get("price", type=float)
        if not name or price is None or price < 0:
            error = "A name and a valid price are required."
        else:
            db.execute(
                "UPDATE menu_items SET name = ?, description = ?, price = ?, category_id = ?, available = ? "
                "WHERE id = ? AND restaurant_id = ?",
                (name, request.form.get("description", "").strip(), price,
                 request.form.get("category_id", type=int),
                 1 if request.form.get("available") == "1" else 0, item_id, rid),
            )
            db.commit()
            return redirect(url_for("admin_menu"))
    categories = db.execute("SELECT * FROM categories WHERE restaurant_id = ? ORDER BY sort_order, id", (rid,)).fetchall()
    return render_template("admin_item_edit.html", item=item, categories=categories, error=error)


@app.route("/admin/tables", methods=["GET", "POST"])
@login_required("admin")
@require_perm("tables.manage")
def admin_tables():
    db = get_db_conn()
    rid = session["restaurant_id"]
    error = None
    if request.method == "POST":
        action = request.form.get("action", "add")
        if action == "add":
            number = request.form.get("number", "").strip()
            branch_id = request.form.get("branch_id", type=int)
            if number:
                db.execute(
                    "INSERT INTO tables_ (restaurant_id, number, qr_token, branch_id) VALUES (?, ?, ?, ?)",
                    (rid, number, secrets.token_urlsafe(8), branch_id),
                )
        elif action == "rename":
            number = request.form.get("number", "").strip()
            if number:
                db.execute("UPDATE tables_ SET number = ?, branch_id = ? WHERE id = ? AND restaurant_id = ?",
                           (number, request.form.get("branch_id", type=int),
                            request.form.get("table_id", type=int), rid))
        elif action == "toggle":
            db.execute("UPDATE tables_ SET active = 1 - active WHERE id = ? AND restaurant_id = ?",
                       (request.form.get("table_id", type=int), rid))
        elif action == "new_link":
            # Issue a fresh QR token; the old printed QR stops working.
            db.execute("UPDATE tables_ SET qr_token = ? WHERE id = ? AND restaurant_id = ?",
                       (secrets.token_urlsafe(8), request.form.get("table_id", type=int), rid))
        db.commit()
        return redirect(url_for("admin_tables"))
    tables = db.execute(
        "SELECT t.*, b.name AS branch_name FROM tables_ t LEFT JOIN branches b ON b.id = t.branch_id "
        "WHERE t.restaurant_id = ? AND t.is_virtual = 0 ORDER BY CAST(t.number AS INTEGER), t.number",
        (rid,)).fetchall()
    branches = db.execute("SELECT * FROM branches WHERE restaurant_id = ? AND active = 1 ORDER BY name",
                          (rid,)).fetchall()
    base = public_base_url()
    qrs = {t["id"]: qr_svg(f"{base}/t/{t['qr_token']}") for t in tables}
    return render_template("admin_tables.html", tables=tables, branches=branches,
                           request_host=base, qrs=qrs, error=error)


def _svg_response(text, filename, download):
    resp = Response(qr_svg(text), mimetype="image/svg+xml")
    if download:
        resp.headers["Content-Disposition"] = f'attachment; filename="{filename}"'
    return resp


@app.route("/admin/tables/<int:table_id>/qr.svg")
@login_required("admin")
@require_perm("tables.manage")
def admin_table_qr(table_id):
    t = get_db_conn().execute("SELECT * FROM tables_ WHERE id = ? AND restaurant_id = ?",
                              (table_id, session["restaurant_id"])).fetchone()
    if t is None:
        abort(404)
    return _svg_response(f"{public_base_url()}/t/{t['qr_token']}", f"table-{t['number']}-qr.svg",
                         request.args.get("download"))


@app.route("/admin/restaurant-qr.svg")
@login_required("admin")
def admin_restaurant_qr():
    """QR for the public order / reservation page (/r/<id>)."""
    return _svg_response(f"{public_base_url()}/r/{session['restaurant_id']}", "restaurant-order-page-qr.svg",
                         request.args.get("download"))


@app.route("/admin/tables/print")
@login_required("admin")
@require_perm("tables.manage")
def admin_tables_print():
    """Printable sheet of QR cards, one per active table."""
    db = get_db_conn()
    rid = session["restaurant_id"]
    base = public_base_url()
    tables = db.execute("SELECT * FROM tables_ WHERE restaurant_id = ? AND is_virtual = 0 AND active = 1 "
                        "ORDER BY CAST(number AS INTEGER), number", (rid,)).fetchall()
    cards = [{"number": t["number"], "svg": qr_svg(f"{base}/t/{t['qr_token']}")} for t in tables]
    return render_template("admin_tables_print.html", cards=cards, restaurant=get_restaurant(rid))


# ---------------------------------------------------------------------------
# Admin: payments
# ---------------------------------------------------------------------------

@app.route("/admin/payments", methods=["GET", "POST"])
@login_required("admin")
@require_perm("payments.manage")
def admin_payments():
    db = get_db_conn()
    rid = session["restaurant_id"]
    error = None
    if request.method == "POST":
        action = request.form.get("action")
        if action == "provider":
            choice = request.form.get("provider")
            if choice not in payments.PROVIDERS:
                abort(400)
            if choice == "GATEWAY" and not payments.gateway_configured():
                error = "Live gateway isn't configured on the server yet (set NEXORA_PAY_API_URL and NEXORA_PAY_WEBHOOK_SECRET)."
            else:
                db.execute("UPDATE restaurants SET payment_provider = ? WHERE id = ?", (choice, rid))
                log_admin_action(db, "payments.provider", f"provider={choice}")
                db.commit()
                return redirect(url_for("admin_payments"))
        elif action == "refunded":
            pid = request.form.get("payment_id", type=int)
            if db.execute("UPDATE payments SET status = 'REFUNDED', note = 'Refund confirmed by admin' "
                          "WHERE id = ? AND restaurant_id = ? AND status = 'REFUND_DUE'", (pid, rid)).rowcount:
                log_admin_action(db, "payments.refunded", f"payment={pid}")
            db.commit()
            return redirect(url_for("admin_payments"))
    rows = db.execute("SELECT * FROM payments WHERE restaurant_id = ? ORDER BY id DESC LIMIT 100", (rid,)).fetchall()
    paid_today = db.execute("SELECT COALESCE(SUM(amount), 0) AS s FROM payments WHERE restaurant_id = ? "
                            "AND status = 'PAID' AND date(completed_at) = date('now')", (rid,)).fetchone()["s"]
    return render_template("admin_payments.html", rows=rows, providers=payments.PROVIDERS, error=error,
                           gateway_ready=payments.gateway_configured(), paid_today=paid_today,
                           webhook_url=public_base_url() + url_for("payment_webhook"),
                           refunds_due=sum(1 for r in rows if r["status"] == "REFUND_DUE"))


@app.route("/admin/staff", methods=["GET", "POST"])
@login_required("admin")
@require_perm("staff.manage")
def admin_staff():
    db = get_db_conn()
    rid = session["restaurant_id"]
    error = request.args.get("error")
    if request.method == "POST":
        action = request.form.get("action", "add")
        if action == "add":
            username = request.form.get("username", "").strip()
            password = request.form.get("password", "")
            role = request.form.get("role")
            if role not in ("admin", "cashier", "kitchen", "waiter"):
                abort(400)
            if not username or len(password) < 6:
                return redirect(url_for("admin_staff", error="Username required and password must be at least 6 characters."))
            if db.execute("SELECT id FROM users WHERE username = ?", (username,)).fetchone():
                return redirect(url_for("admin_staff", error="That username is already taken."))
            db.execute(
                "INSERT INTO users (restaurant_id, username, password_hash, role, branch_id) VALUES (?, ?, ?, ?, ?)",
                (rid, username, generate_password_hash(password), role, request.form.get("branch_id", type=int)),
            )
            log_admin_action(db, "staff.add", f"username={username} role={role}")
        else:
            user_id = request.form.get("user_id", type=int)
            target = db.execute("SELECT * FROM users WHERE id = ? AND restaurant_id = ?", (user_id, rid)).fetchone()
            if target is None:
                abort(404)
            other_active_admins = db.execute(
                "SELECT COUNT(*) AS c FROM users WHERE restaurant_id = ? AND role = 'admin' "
                "AND active = 1 AND id != ?", (rid, user_id)).fetchone()["c"]
            if action == "toggle":
                if target["id"] == session["user_id"]:
                    return redirect(url_for("admin_staff", error="You can't deactivate your own account."))
                if target["role"] == "admin" and target["active"] and other_active_admins == 0:
                    return redirect(url_for("admin_staff", error="At least one active admin is required."))
                db.execute("UPDATE users SET active = 1 - active WHERE id = ?", (user_id,))
                log_admin_action(db, "staff.toggle_active", f"user={target['username']} now_active={not target['active']}")
            elif action == "set_role":
                role = request.form.get("role")
                if role not in ("admin", "cashier", "kitchen", "waiter"):
                    abort(400)
                if target["role"] == "admin" and role != "admin" and other_active_admins == 0:
                    return redirect(url_for("admin_staff", error="At least one active admin is required."))
                db.execute("UPDATE users SET role = ? WHERE id = ?", (role, user_id))
                log_admin_action(db, "staff.set_role", f"user={target['username']} role={target['role']}->{role}")
            elif action == "set_branch":
                db.execute("UPDATE users SET branch_id = ? WHERE id = ?",
                           (request.form.get("branch_id", type=int), user_id))
                log_admin_action(db, "staff.set_branch", f"user={target['username']}")
            elif action == "reset_password":
                password = request.form.get("password", "")
                if len(password) < 6:
                    return redirect(url_for("admin_staff", error="Password must be at least 6 characters."))
                db.execute("UPDATE users SET password_hash = ? WHERE id = ?",
                           (generate_password_hash(password), user_id))
                log_admin_action(db, "staff.reset_password", f"user={target['username']}")
        db.commit()
        return redirect(url_for("admin_staff"))
    staff = db.execute(
        "SELECT u.id, u.username, u.role, u.active, u.branch_id, b.name AS branch_name FROM users u "
        "LEFT JOIN branches b ON b.id = u.branch_id WHERE u.restaurant_id = ? ORDER BY u.id",
        (rid,)).fetchall()
    branches = db.execute("SELECT * FROM branches WHERE restaurant_id = ? AND active = 1 ORDER BY name",
                          (rid,)).fetchall()
    return render_template("admin_staff.html", staff=staff, branches=branches, error=error)


# ---------------------------------------------------------------------------
# Admin: inventory
# ---------------------------------------------------------------------------

@app.route("/admin/inventory", methods=["GET", "POST"])
@login_required("admin")
@require_perm("inventory.manage")
def admin_inventory():
    db = get_db_conn()
    rid = session["restaurant_id"]
    if request.method == "POST":
        action = request.form.get("action")
        item_id = request.form.get("item_id", type=int)
        if action == "add":
            name = request.form.get("name", "").strip()
            unit = request.form.get("unit", "").strip() or "pcs"
            qty = request.form.get("quantity", type=float, default=0.0)
            threshold = request.form.get("threshold", type=float, default=0.0)
            if not name or qty < 0 or threshold < 0:
                return redirect(url_for("admin_inventory", error="Enter a name and non-negative numbers."))
            cur = db.execute(
                "INSERT INTO inventory_items (restaurant_id, name, unit, quantity, low_stock_threshold) "
                "VALUES (?, ?, ?, ?, ?)", (rid, name, unit, qty, threshold))
            if qty > 0:
                db.execute("INSERT INTO stock_movements (restaurant_id, inventory_item_id, change, reason, user_id) "
                           "VALUES (?, ?, ?, 'Opening stock', ?)", (rid, cur.lastrowid, qty, session["user_id"]))
        elif action in ("edit", "adjust", "toggle"):
            inv = db.execute("SELECT * FROM inventory_items WHERE id = ? AND restaurant_id = ?",
                             (item_id, rid)).fetchone()
            if inv is None:
                abort(404)
            if action == "edit":
                name = request.form.get("name", "").strip()
                threshold = request.form.get("threshold", type=float)
                if not name or threshold is None or threshold < 0:
                    return redirect(url_for("admin_inventory", error="Enter a name and a valid alert level."))
                db.execute("UPDATE inventory_items SET name = ?, unit = ?, low_stock_threshold = ? WHERE id = ?",
                           (name, request.form.get("unit", "").strip() or "pcs", threshold, item_id))
            elif action == "toggle":
                db.execute("UPDATE inventory_items SET active = 1 - active WHERE id = ?", (item_id,))
            else:
                delta = request.form.get("delta", type=float)
                if not delta:
                    return redirect(url_for("admin_inventory", error="Enter an amount to add or remove."))
                if inv["quantity"] + delta < 0:
                    return redirect(url_for("admin_inventory", error="Stock can't go below zero."))
                db.execute("UPDATE inventory_items SET quantity = quantity + ? WHERE id = ?", (delta, item_id))
                reason = request.form.get("reason", "").strip() or ("Restock" if delta > 0 else "Adjustment")
                db.execute("INSERT INTO stock_movements (restaurant_id, inventory_item_id, change, reason, user_id) "
                           "VALUES (?, ?, ?, ?, ?)", (rid, item_id, delta, reason, session["user_id"]))
        db.commit()
        return redirect(url_for("admin_inventory"))
    inventory = db.execute(
        "SELECT * FROM inventory_items WHERE restaurant_id = ? ORDER BY active DESC, name", (rid,)).fetchall()
    movements = db.execute(
        "SELECT m.*, inv.name AS item_name, inv.unit, u.username FROM stock_movements m "
        "JOIN inventory_items inv ON inv.id = m.inventory_item_id LEFT JOIN users u ON u.id = m.user_id "
        "WHERE m.restaurant_id = ? ORDER BY m.id DESC LIMIT 20", (rid,)).fetchall()
    return render_template("admin_inventory.html", inventory=inventory, movements=movements,
                           error=request.args.get("error"))


@app.route("/admin/menu/item/<int:item_id>/recipe", methods=["GET", "POST"])
@login_required("admin")
@require_perm("menu.manage")
def admin_recipe(item_id):
    db = get_db_conn()
    rid = session["restaurant_id"]
    item = db.execute("SELECT * FROM menu_items WHERE id = ? AND restaurant_id = ?", (item_id, rid)).fetchone()
    if item is None:
        abort(404)
    if request.method == "POST":
        if request.form.get("action") == "remove":
            db.execute("DELETE FROM menu_item_ingredients WHERE id = ? AND menu_item_id = ?",
                       (request.form.get("row_id", type=int), item_id))
        else:
            inv_id = request.form.get("inventory_item_id", type=int)
            qty = request.form.get("quantity", type=float)
            inv = db.execute("SELECT id FROM inventory_items WHERE id = ? AND restaurant_id = ?",
                             (inv_id, rid)).fetchone()
            if inv is None or qty is None or qty <= 0:
                return redirect(url_for("admin_recipe", item_id=item_id, error="Pick an ingredient and an amount above zero."))
            db.execute(
                "INSERT INTO menu_item_ingredients (menu_item_id, inventory_item_id, quantity) VALUES (?, ?, ?) "
                "ON CONFLICT(menu_item_id, inventory_item_id) DO UPDATE SET quantity = excluded.quantity",
                (item_id, inv_id, qty))
        db.commit()
        return redirect(url_for("admin_recipe", item_id=item_id))
    rows = db.execute(
        "SELECT r.id, r.quantity, inv.name, inv.unit, inv.active FROM menu_item_ingredients r "
        "JOIN inventory_items inv ON inv.id = r.inventory_item_id WHERE r.menu_item_id = ? ORDER BY inv.name",
        (item_id,)).fetchall()
    choices = db.execute("SELECT * FROM inventory_items WHERE restaurant_id = ? AND active = 1 ORDER BY name",
                         (rid,)).fetchall()
    return render_template("admin_recipe.html", item=item, rows=rows, choices=choices,
                           error=request.args.get("error"))


# ---------------------------------------------------------------------------
# Admin: promotions
# ---------------------------------------------------------------------------

def parse_promo_form(form):
    name = form.get("name", "").strip()
    code = form.get("code", "").strip().upper() or None
    kind = form.get("kind")
    value = form.get("value", type=float)
    min_order = form.get("min_order", type=float, default=0.0)
    starts = form.get("starts_on", "").strip() or None
    ends = form.get("ends_on", "").strip() or None
    max_uses = form.get("max_uses", type=int)
    for d in (starts, ends):
        if d:
            try:
                date.fromisoformat(d)
            except ValueError:
                return None, "Dates must be valid."
    if not name:
        return None, "Give the promotion a name."
    if kind not in ("PERCENT", "FIXED"):
        return None, "Choose percent or fixed amount."
    if value is None or value <= 0 or (kind == "PERCENT" and value > 100):
        return None, "Enter a discount above zero (percent can't exceed 100)."
    if min_order < 0:
        return None, "Minimum order can't be negative."
    if starts and ends and starts > ends:
        return None, "The end date must be after the start date."
    if max_uses is not None and max_uses < 1:
        return None, "Max uses must be at least 1 (or blank for unlimited)."
    return {"name": name, "code": code, "kind": kind, "value": value, "min_order": min_order,
            "starts_on": starts, "ends_on": ends, "max_uses": max_uses}, None


def promo_code_taken(db, rid, code, exclude_id=None):
    if not code:
        return False
    return db.execute("SELECT 1 FROM promotions WHERE restaurant_id = ? AND UPPER(code) = ? AND id != ?",
                      (rid, code.upper(), exclude_id or 0)).fetchone() is not None


@app.route("/admin/promotions", methods=["GET", "POST"])
@login_required("admin")
@require_perm("promotions.manage")
def admin_promotions():
    db = get_db_conn()
    rid = session["restaurant_id"]
    if request.method == "POST":
        action = request.form.get("action")
        if action == "add":
            data, error = parse_promo_form(request.form)
            if not error and promo_code_taken(db, rid, data["code"]):
                error = "That code is already used by another promotion."
            if error:
                return redirect(url_for("admin_promotions", error=error))
            db.execute(
                "INSERT INTO promotions (restaurant_id, name, code, kind, value, min_order, starts_on, ends_on, max_uses) "
                "VALUES (:rid, :name, :code, :kind, :value, :min_order, :starts_on, :ends_on, :max_uses)",
                {**data, "rid": rid})
        elif action == "toggle":
            db.execute("UPDATE promotions SET active = 1 - active WHERE id = ? AND restaurant_id = ?",
                       (request.form.get("promo_id", type=int), rid))
        elif action == "delete":
            pid = request.form.get("promo_id", type=int)
            used = db.execute("SELECT 1 FROM orders WHERE promotion_id = ? LIMIT 1", (pid,)).fetchone()
            if used:  # keep history intact; just switch it off
                db.execute("UPDATE promotions SET active = 0 WHERE id = ? AND restaurant_id = ?", (pid, rid))
            else:
                db.execute("DELETE FROM promotions WHERE id = ? AND restaurant_id = ?", (pid, rid))
        db.commit()
        return redirect(url_for("admin_promotions"))
    promos = db.execute("SELECT * FROM promotions WHERE restaurant_id = ? ORDER BY active DESC, id DESC",
                        (rid,)).fetchall()
    return render_template("admin_promotions.html", promos=promos, today=date.today().isoformat(),
                           error=request.args.get("error"))


@app.route("/admin/promotions/<int:promo_id>/edit", methods=["GET", "POST"])
@login_required("admin")
@require_perm("promotions.manage")
def admin_promotion_edit(promo_id):
    db = get_db_conn()
    rid = session["restaurant_id"]
    promo = db.execute("SELECT * FROM promotions WHERE id = ? AND restaurant_id = ?", (promo_id, rid)).fetchone()
    if promo is None:
        abort(404)
    error = None
    if request.method == "POST":
        data, error = parse_promo_form(request.form)
        if not error and promo_code_taken(db, rid, data["code"], promo_id):
            error = "That code is already used by another promotion."
        if not error:
            db.execute(
                "UPDATE promotions SET name = :name, code = :code, kind = :kind, value = :value, "
                "min_order = :min_order, starts_on = :starts_on, ends_on = :ends_on, max_uses = :max_uses "
                "WHERE id = :id AND restaurant_id = :rid", {**data, "id": promo_id, "rid": rid})
            db.commit()
            return redirect(url_for("admin_promotions"))
    return render_template("admin_promotion_edit.html", promo=promo, error=error)


# ---------------------------------------------------------------------------
# Admin: staff performance + customer feedback
# ---------------------------------------------------------------------------

RANGES = {"24h": ("Last 24 hours", 24), "7d": ("Last 7 days", 24 * 7),
          "30d": ("Last 30 days", 24 * 30), "all": ("All time", None)}


@app.route("/admin/performance")
@login_required("admin")
@require_perm("performance.view")
def admin_performance():
    db = get_db_conn()
    rid = session["restaurant_id"]
    range_key = request.args.get("range", "7d")
    if range_key not in RANGES:
        range_key = "7d"
    hours = RANGES[range_key][1]
    since = "0000-00-00 00:00:00" if hours is None else \
        (datetime.now(timezone.utc) - timedelta(hours=hours)).strftime("%Y-%m-%d %H:%M:%S")
    params = {"since": since, "rid": rid}

    cashiers = db.execute(
        "SELECT u.username, u.active, "
        " (SELECT COUNT(*) FROM order_events e WHERE e.user_id = u.id AND e.action = 'SENT_TO_KITCHEN' "
        "   AND e.created_at >= :since) AS sent, "
        " (SELECT COUNT(*) FROM order_events e WHERE e.user_id = u.id AND e.action = 'CANCELLED' "
        "   AND e.created_at >= :since) AS cancelled, "
        " (SELECT AVG((julianday(e.created_at) - julianday(o.placed_at)) * 1440) FROM order_events e "
        "   JOIN orders o ON o.id = e.order_id WHERE e.user_id = u.id AND e.action = 'SENT_TO_KITCHEN' "
        "   AND e.created_at >= :since AND o.placed_at IS NOT NULL) AS avg_confirm "
        "FROM users u WHERE u.restaurant_id = :rid AND u.role = 'cashier' ORDER BY u.username", params).fetchall()
    kitchen = db.execute(
        "SELECT u.username, u.active, "
        " (SELECT COUNT(*) FROM order_events e WHERE e.user_id = u.id AND e.action = 'READY' "
        "   AND e.created_at >= :since) AS ready, "
        " (SELECT COUNT(*) FROM order_events e WHERE e.user_id = u.id AND e.action = 'SERVED' "
        "   AND e.created_at >= :since) AS served, "
        " (SELECT AVG((julianday(e.created_at) - julianday(s.created_at)) * 1440) FROM order_events e "
        "   JOIN order_events s ON s.order_id = e.order_id AND s.action = 'SENT_TO_KITCHEN' "
        "   WHERE e.user_id = u.id AND e.action = 'READY' AND e.created_at >= :since) AS avg_prep "
        "FROM users u WHERE u.restaurant_id = :rid AND u.role = 'kitchen' ORDER BY u.username", params).fetchall()
    waiters = db.execute(
        "SELECT u.username, u.active, "
        " (SELECT COUNT(*) FROM service_requests sr WHERE sr.accepted_by = u.id "
        "   AND sr.accepted_at >= :since) AS accepted, "
        " (SELECT COUNT(*) FROM service_requests sr WHERE sr.completed_by = u.id "
        "   AND sr.completed_at >= :since) AS completed, "
        " (SELECT AVG((julianday(sr.accepted_at) - julianday(sr.created_at)) * 1440) FROM service_requests sr "
        "   WHERE sr.accepted_by = u.id AND sr.accepted_at >= :since) AS avg_response "
        "FROM users u WHERE u.restaurant_id = :rid AND u.role = 'waiter' ORDER BY u.username", params).fetchall()
    return render_template("admin_performance.html", cashiers=cashiers, kitchen=kitchen, waiters=waiters,
                           ranges=RANGES, range_key=range_key)


@app.route("/admin/feedback")
@login_required("admin")
@require_perm("feedback.view")
def admin_feedback():
    db = get_db_conn()
    rid = session["restaurant_id"]
    rating_filter = request.args.get("rating", type=int)
    summary = db.execute("SELECT COUNT(*) AS n, ROUND(AVG(rating), 2) AS avg FROM feedback WHERE restaurant_id = ?",
                         (rid,)).fetchone()
    dist = {r["rating"]: r["n"] for r in db.execute(
        "SELECT rating, COUNT(*) AS n FROM feedback WHERE restaurant_id = ? GROUP BY rating", (rid,))}
    query = ("SELECT f.*, t.number AS table_number FROM feedback f JOIN tables_ t ON t.id = f.table_id "
             "WHERE f.restaurant_id = ?")
    args = [rid]
    if rating_filter in (1, 2, 3, 4, 5):
        query += " AND f.rating = ?"
        args.append(rating_filter)
    reviews = db.execute(query + " ORDER BY f.id DESC LIMIT 100", args).fetchall()
    return render_template("admin_feedback.html", summary=summary, dist=dist, reviews=reviews,
                           rating_filter=rating_filter)


# ---------------------------------------------------------------------------
# Admin: branches (multi-branch)
# ---------------------------------------------------------------------------

@app.route("/admin/branches", methods=["GET", "POST"])
@login_required("admin")
@require_perm("branches.manage")
def admin_branches():
    db = get_db_conn()
    rid = session["restaurant_id"]
    error = None
    if request.method == "POST":
        action = request.form.get("action", "add")
        if action == "add":
            name = request.form.get("name", "").strip()
            if not name:
                error = "Give the branch a name."
            else:
                db.execute("INSERT INTO branches (restaurant_id, name, address, phone) VALUES (?, ?, ?, ?)",
                           (rid, name, request.form.get("address", "").strip(),
                            request.form.get("phone", "").strip()))
        elif action == "edit":
            name = request.form.get("name", "").strip()
            branch_id = request.form.get("branch_id", type=int)
            if not name:
                error = "Give the branch a name."
            else:
                db.execute("UPDATE branches SET name = ?, address = ?, phone = ? WHERE id = ? AND restaurant_id = ?",
                           (name, request.form.get("address", "").strip(),
                            request.form.get("phone", "").strip(), branch_id, rid))
        elif action == "toggle":
            db.execute("UPDATE branches SET active = 1 - active WHERE id = ? AND restaurant_id = ?",
                       (request.form.get("branch_id", type=int), rid))
        if error:
            branches = db.execute("SELECT * FROM branches WHERE restaurant_id = ? ORDER BY id", (rid,)).fetchall()
            return render_template("admin_branches.html", branches=branches, error=error)
        db.commit()
        return redirect(url_for("admin_branches"))
    branches = db.execute("SELECT * FROM branches WHERE restaurant_id = ? ORDER BY id", (rid,)).fetchall()
    return render_template("admin_branches.html", branches=branches, error=error)


# ---------------------------------------------------------------------------
# Admin: customer accounts + loyalty
# ---------------------------------------------------------------------------

@app.route("/admin/customers", methods=["GET", "POST"])
@login_required("admin")
@require_perm("customers.manage")
def admin_customers():
    db = get_db_conn()
    rid = session["restaurant_id"]
    error = None
    if request.method == "POST":
        customer_id = request.form.get("customer_id", type=int)
        cust = db.execute("SELECT * FROM customers WHERE id = ? AND restaurant_id = ?",
                          (customer_id, rid)).fetchone()
        if cust is None:
            abort(404)
        delta = request.form.get("delta", type=int)
        if not delta:
            error = "Enter a non-zero number of points to add or remove."
        elif cust["loyalty_points"] + delta < 0:
            error = "That would take the customer below zero points."
        else:
            loyalty_ledger(db, customer_id, None, delta, request.form.get("reason", "").strip() or "Manual adjustment")
            db.commit()
            return redirect(url_for("admin_customers"))
    customers = db.execute(
        "SELECT c.*, (SELECT COUNT(*) FROM orders o WHERE o.customer_id = c.id AND o.status != 'CART') AS order_count, "
        "(SELECT COALESCE(SUM(total), 0) FROM orders o WHERE o.customer_id = c.id AND o.payment_status = 'PAID') AS spent "
        "FROM customers c WHERE c.restaurant_id = ? ORDER BY c.loyalty_points DESC", (rid,)
    ).fetchall()
    return render_template("admin_customers.html", customers=customers, error=error)


# ---------------------------------------------------------------------------
# Admin: reservations
# ---------------------------------------------------------------------------

RESERVATION_ADVANCE = {"REQUESTED": "CONFIRMED", "CONFIRMED": "SEATED"}


@app.route("/admin/reservations")
@login_required("admin")
@require_perm("reservations.manage")
def admin_reservations():
    db = get_db_conn()
    rid = session["restaurant_id"]
    show_all = request.args.get("all") == "1"
    query = (
        "SELECT r.*, b.name AS branch_name, t.number AS table_number FROM reservations r "
        "LEFT JOIN branches b ON b.id = r.branch_id LEFT JOIN tables_ t ON t.id = r.table_id "
        "WHERE r.restaurant_id = ?"
    )
    if not show_all:
        query += " AND r.status IN ('REQUESTED', 'CONFIRMED')"
    reservations = db.execute(query + " ORDER BY r.reservation_time", (rid,)).fetchall()
    tables = db.execute("SELECT * FROM tables_ WHERE restaurant_id = ? AND active = 1 AND is_virtual = 0 "
                        "ORDER BY CAST(number AS INTEGER), number", (rid,)).fetchall()
    return render_template("admin_reservations.html", reservations=reservations, tables=tables, show_all=show_all)


@app.route("/admin/reservations/<int:reservation_id>/update", methods=["POST"])
@login_required("admin", "waiter")
@require_perm("reservations.manage")
def admin_update_reservation(reservation_id):
    db = get_db_conn()
    rid = session["restaurant_id"]
    res = db.execute("SELECT * FROM reservations WHERE id = ? AND restaurant_id = ?",
                     (reservation_id, rid)).fetchone()
    if res is None:
        abort(404)
    action = request.form.get("action")
    if action == "advance":
        next_status = RESERVATION_ADVANCE.get(res["status"])
        if next_status:
            table_id = request.form.get("table_id", type=int) if next_status == "SEATED" else res["table_id"]
            db.execute("UPDATE reservations SET status = ?, table_id = ? WHERE id = ?",
                       (next_status, table_id, reservation_id))
    elif action == "cancel":
        db.execute("UPDATE reservations SET status = 'CANCELLED' WHERE id = ?", (reservation_id,))
    elif action == "no_show":
        db.execute("UPDATE reservations SET status = 'NO_SHOW' WHERE id = ?", (reservation_id,))
    db.commit()
    return redirect(url_for("admin_reservations") if session["role"] == "admin" else url_for("waiter_dashboard"))


# ---------------------------------------------------------------------------
# Admin: advanced permissions
# ---------------------------------------------------------------------------

@app.route("/admin/permissions", methods=["GET", "POST"])
@login_required("admin")
@require_perm("permissions.manage")
def admin_permissions():
    db = get_db_conn()
    rid = session["restaurant_id"]
    error = None
    if request.method == "POST":
        user_id = request.form.get("user_id", type=int)
        target = db.execute("SELECT * FROM users WHERE id = ? AND restaurant_id = ? AND role = 'admin'",
                            (user_id, rid)).fetchone()
        if target is None:
            abort(404)
        if target["id"] == session["user_id"]:
            error = "You can't change your own permissions -- ask another admin."
        else:
            granted = set(request.form.getlist("perm"))
            revoked = [p for p in ADMIN_PERMISSIONS if p not in granted]
            # Never allow every admin to lose permissions.manage -- that would lock everyone out.
            others_with_perm_manage = db.execute(
                "SELECT id, revoked_permissions FROM users WHERE restaurant_id = ? AND role = 'admin' "
                "AND active = 1 AND id != ?", (rid, user_id)).fetchall()
            others_have_it = any("permissions.manage" not in (o["revoked_permissions"] or "").split(",")
                                 for o in others_with_perm_manage)
            if "permissions.manage" in revoked and not others_have_it:
                error = "At least one other admin must keep the Permissions permission."
            else:
                db.execute("UPDATE users SET revoked_permissions = ? WHERE id = ?",
                           (",".join(revoked), user_id))
                log_admin_action(db, "permissions.update", f"user={target['username']} revoked={revoked}")
                db.commit()
                return redirect(url_for("admin_permissions"))
    admins = db.execute("SELECT id, username, revoked_permissions FROM users WHERE restaurant_id = ? "
                        "AND role = 'admin' ORDER BY id", (rid,)).fetchall()
    return render_template("admin_permissions.html", admins=admins, permissions=ADMIN_PERMISSIONS,
                           labels=PERMISSION_LABELS, error=error)


# ---------------------------------------------------------------------------
# Admin: public API keys
# ---------------------------------------------------------------------------

@app.route("/admin/api-keys", methods=["GET", "POST"])
@login_required("admin")
@require_perm("api_keys.manage")
def admin_api_keys():
    db = get_db_conn()
    rid = session["restaurant_id"]
    new_key = None
    if request.method == "POST":
        action = request.form.get("action", "create")
        if action == "create":
            label = request.form.get("label", "").strip() or "Untitled key"
            raw_key = secrets.token_urlsafe(32)
            prefix = raw_key[:10]
            db.execute(
                "INSERT INTO api_keys (restaurant_id, label, key_prefix, key_hash, created_by) "
                "VALUES (?, ?, ?, ?, ?)",
                (rid, label, prefix, generate_password_hash(raw_key), session["user_id"]),
            )
            log_admin_action(db, "api_key.create", f"label={label}")
            db.commit()
            new_key = raw_key
        elif action == "toggle":
            key_id = request.form.get("key_id", type=int)
            key = db.execute("SELECT label FROM api_keys WHERE id = ? AND restaurant_id = ?",
                             (key_id, rid)).fetchone()
            db.execute("UPDATE api_keys SET active = 1 - active WHERE id = ? AND restaurant_id = ?",
                       (key_id, rid))
            log_admin_action(db, "api_key.toggle", f"label={key['label'] if key else key_id}")
            db.commit()
    keys = db.execute("SELECT * FROM api_keys WHERE restaurant_id = ? ORDER BY id DESC", (rid,)).fetchall()
    return render_template("admin_api_keys.html", keys=keys, new_key=new_key,
                           api_base=request.host_url.rstrip("/") + "/api/v1")


# ---------------------------------------------------------------------------
# Admin: accounting integration
# ---------------------------------------------------------------------------

@app.route("/admin/accounting", methods=["GET", "POST"])
@login_required("admin")
@require_perm("accounting.manage")
def admin_accounting():
    db = get_db_conn()
    rid = session["restaurant_id"]
    saved = request.args.get("saved")
    if request.method == "POST":
        url = request.form.get("webhook_url", "").strip()
        if url and not (url.startswith("http://") or url.startswith("https://")):
            flash("Webhook URL must start with http:// or https://")
        else:
            db.execute("UPDATE restaurants SET accounting_webhook_url = ? WHERE id = ?", (url, rid))
            log_admin_action(db, "accounting.webhook_update", url or "(cleared)")
            db.commit()
            return redirect(url_for("admin_accounting", saved=1))
    restaurant = get_restaurant(rid)
    return render_template("admin_accounting.html", restaurant=restaurant, saved=saved)


@app.route("/admin/accounting/export/<kind>")
@login_required("admin")
@require_perm("accounting.manage")
def admin_accounting_export(kind):
    import csv
    import io
    db = get_db_conn()
    rid = session["restaurant_id"]
    days = request.args.get("days", type=int, default=30)
    since = (datetime.now(timezone.utc) - timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S")
    buf = io.StringIO()
    writer = csv.writer(buf)
    if kind == "transactions":
        writer.writerow(["order_id", "date", "branch", "type", "subtotal", "discount", "delivery_fee",
                         "loyalty_redeemed", "total", "payment_status", "status"])
        rows = db.execute(
            "SELECT o.id, o.placed_at, b.name AS branch, o.order_type, o.subtotal, o.discount, "
            "o.delivery_fee, o.loyalty_redeemed_value, o.total, o.payment_status, o.status FROM orders o "
            "LEFT JOIN branches b ON b.id = o.branch_id WHERE o.restaurant_id = ? AND o.status != 'CART' "
            "AND (o.placed_at >= ? OR o.placed_at IS NULL) ORDER BY o.id", (rid, since)
        ).fetchall()
        for r in rows:
            writer.writerow([r["id"], r["placed_at"] or "", r["branch"] or "", r["order_type"], r["subtotal"],
                             r["discount"], r["delivery_fee"], r["loyalty_redeemed_value"], r["total"],
                             r["payment_status"], r["status"]])
        filename = "nexora_transactions.csv"
    elif kind == "daily_summary":
        writer.writerow(["date", "orders", "subtotal", "discounts", "delivery_fees", "total_revenue"])
        rows = db.execute(
            "SELECT DATE(placed_at) AS day, COUNT(*) AS orders, SUM(subtotal) AS subtotal, "
            "SUM(discount) AS discounts, SUM(delivery_fee) AS delivery_fees, SUM(total) AS total_revenue "
            "FROM orders WHERE restaurant_id = ? AND payment_status = 'PAID' AND placed_at >= ? "
            "GROUP BY DATE(placed_at) ORDER BY day", (rid, since)
        ).fetchall()
        for r in rows:
            writer.writerow([r["day"], r["orders"], r["subtotal"], r["discounts"], r["delivery_fees"],
                             r["total_revenue"]])
        filename = "nexora_daily_summary.csv"
    else:
        abort(404)
    log_admin_action(db, "accounting.export", f"kind={kind} days={days}")
    db.commit()
    return Response(buf.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": f"attachment; filename={filename}"})


# ---------------------------------------------------------------------------
# Admin: audit log
# ---------------------------------------------------------------------------

@app.route("/admin/audit-log")
@login_required("admin")
@require_perm("audit.view")
def admin_audit_log():
    db = get_db_conn()
    rid = session["restaurant_id"]
    entries = db.execute(
        "SELECT a.*, u.username FROM audit_log a LEFT JOIN users u ON u.id = a.user_id "
        "WHERE a.restaurant_id = ? ORDER BY a.id DESC LIMIT 200", (rid,)
    ).fetchall()
    return render_template("admin_audit_log.html", entries=entries)


# ---------------------------------------------------------------------------
# Public read/write API (authenticated with an API key from Admin -> API Keys)
# ---------------------------------------------------------------------------

def api_key_required(view):
    @functools.wraps(view)
    def wrapped(*args, **kwargs):
        db = get_db_conn()
        auth = request.headers.get("Authorization", "")
        raw_key = auth[7:] if auth.startswith("Bearer ") else request.headers.get("X-API-Key", "")
        if not raw_key:
            return jsonify({"error": "Missing API key. Send 'Authorization: Bearer <key>'."}), 401
        prefix = raw_key[:10]
        candidates = db.execute("SELECT * FROM api_keys WHERE key_prefix = ? AND active = 1", (prefix,)).fetchall()
        match = next((k for k in candidates if check_password_hash(k["key_hash"], raw_key)), None)
        if match is None:
            return jsonify({"error": "Invalid or inactive API key."}), 401
        db.execute("UPDATE api_keys SET last_used_at = CURRENT_TIMESTAMP WHERE id = ?", (match["id"],))
        db.commit()
        g.api_restaurant_id = match["restaurant_id"]
        return view(*args, **kwargs)
    return wrapped


@app.route("/api/v1/menu")
@api_key_required
def api_menu():
    db = get_db_conn()
    rid = g.api_restaurant_id
    categories = db.execute("SELECT id, name, active FROM categories WHERE restaurant_id = ? ORDER BY sort_order",
                            (rid,)).fetchall()
    items = db.execute("SELECT id, category_id, name, description, price, available FROM menu_items "
                       "WHERE restaurant_id = ?", (rid,)).fetchall()
    return jsonify({
        "categories": [dict(c) for c in categories],
        "items": [dict(i) for i in items],
    })


@app.route("/api/v1/orders")
@api_key_required
def api_orders():
    db = get_db_conn()
    rid = g.api_restaurant_id
    status = request.args.get("status")
    limit = min(request.args.get("limit", type=int, default=50), 200)
    query = "SELECT * FROM orders WHERE restaurant_id = ? AND status != 'CART'"
    params = [rid]
    if status:
        query += " AND status = ?"
        params.append(status.upper())
    query += " ORDER BY id DESC LIMIT ?"
    params.append(limit)
    orders = db.execute(query, params).fetchall()
    return jsonify({"orders": [dict(o) for o in orders]})


@app.route("/api/v1/orders/<int:order_id>")
@api_key_required
def api_order_detail(order_id):
    db = get_db_conn()
    order = db.execute("SELECT * FROM orders WHERE id = ? AND restaurant_id = ?",
                       (order_id, g.api_restaurant_id)).fetchone()
    if order is None:
        return jsonify({"error": "Order not found."}), 404
    items = db.execute(
        "SELECT oi.quantity, oi.unit_price, mi.name FROM order_items oi "
        "JOIN menu_items mi ON mi.id = oi.menu_item_id WHERE oi.order_id = ?", (order_id,)
    ).fetchall()
    result = dict(order)
    result["items"] = [dict(i) for i in items]
    return jsonify(result)


@app.route("/api/v1/inventory")
@api_key_required
def api_inventory():
    db = get_db_conn()
    rows = db.execute("SELECT id, name, unit, quantity, low_stock_threshold, active FROM inventory_items "
                      "WHERE restaurant_id = ?", (g.api_restaurant_id,)).fetchall()
    return jsonify({"inventory": [dict(r) for r in rows]})


@app.route("/api/v1/customers")
@api_key_required
def api_customers():
    db = get_db_conn()
    rows = db.execute("SELECT id, name, phone, loyalty_points FROM customers WHERE restaurant_id = ?",
                      (g.api_restaurant_id,)).fetchall()
    return jsonify({"customers": [dict(r) for r in rows]})


@app.route("/api/v1/reservations", methods=["GET", "POST"])
@api_key_required
def api_reservations():
    db = get_db_conn()
    rid = g.api_restaurant_id
    if request.method == "POST":
        data = request.get_json(silent=True) or request.form
        name = (data.get("name") or "").strip()
        phone = (data.get("phone") or "").strip()
        party_size = data.get("party_size")
        when = data.get("reservation_time") or ""
        try:
            party_size = int(party_size)
            when_dt = datetime.fromisoformat(when)
            valid = party_size >= 1 and when_dt > datetime.now()
        except (TypeError, ValueError):
            valid = False
        if not name or not phone or not valid:
            return jsonify({"error": "name, phone, party_size (>=1) and a future reservation_time "
                                     "(ISO 8601) are required."}), 400
        cur = db.execute(
            "INSERT INTO reservations (restaurant_id, guest_name, guest_phone, party_size, reservation_time, notes) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (rid, name, phone, party_size, when_dt.strftime("%Y-%m-%d %H:%M:%S"), (data.get("notes") or "")[:500]),
        )
        db.commit()
        return jsonify({"id": cur.lastrowid, "status": "REQUESTED"}), 201
    status = request.args.get("status")
    query = "SELECT * FROM reservations WHERE restaurant_id = ?"
    params = [rid]
    if status:
        query += " AND status = ?"
        params.append(status.upper())
    rows = db.execute(query + " ORDER BY reservation_time DESC LIMIT 100", params).fetchall()
    return jsonify({"reservations": [dict(r) for r in rows]})


# ---------------------------------------------------------------------------
# Cashier dashboard
# ---------------------------------------------------------------------------

@app.route("/cashier")
@login_required("cashier")
def cashier_dashboard():
    db = get_db_conn()
    rid = session["restaurant_id"]
    branch = session.get("branch_id")
    orders = db.execute(
        "SELECT o.*, t.number AS table_number FROM orders o JOIN tables_ t ON t.id = o.table_id "
        "WHERE o.restaurant_id = ? AND o.status IN ('NEW', 'CONFIRMED') "
        "AND (? IS NULL OR o.branch_id IS NULL OR o.branch_id = ?) ORDER BY o.created_at",
        (rid, branch, branch),
    ).fetchall()
    return render_template("cashier_dashboard.html", orders=orders)


@app.route("/cashier/order/<int:order_id>")
@login_required("cashier")
def cashier_order_detail(order_id):
    db = get_db_conn()
    rid = session["restaurant_id"]
    order = db.execute(
        "SELECT o.*, t.number AS table_number FROM orders o JOIN tables_ t ON t.id = o.table_id "
        "WHERE o.id = ? AND o.restaurant_id = ?",
        (order_id, rid),
    ).fetchone()
    if order is None:
        abort(404)
    items = db.execute(
        "SELECT oi.*, mi.name FROM order_items oi JOIN menu_items mi ON mi.id = oi.menu_item_id "
        "WHERE oi.order_id = ?",
        (order_id,),
    ).fetchall()
    return render_template("cashier_order_detail.html", order=order, items=items)


@app.route("/cashier/order/<int:order_id>/send-to-kitchen", methods=["POST"])
@login_required("cashier")
def cashier_send_to_kitchen(order_id):
    db = get_db_conn()
    rid = session["restaurant_id"]
    moved = db.execute(
        "UPDATE orders SET status = 'PREPARING', updated_at = CURRENT_TIMESTAMP "
        "WHERE id = ? AND restaurant_id = ? AND status IN ('NEW', 'CONFIRMED')",
        (order_id, rid),
    ).rowcount
    if moved:  # only the first send counts, so stock is deducted exactly once
        deduct_stock_for_order(db, order_id, session["user_id"])
        log_order_event(db, order_id, session["user_id"], "SENT_TO_KITCHEN")
    db.commit()
    return redirect(url_for("cashier_dashboard"))


@app.route("/cashier/order/<int:order_id>/cancel", methods=["POST"])
@login_required("cashier")
def cashier_cancel_order(order_id):
    db = get_db_conn()
    rid = session["restaurant_id"]
    # Only orders that haven't reached the kitchen can be cancelled.
    cancelled = db.execute(
        "UPDATE orders SET status = 'CANCELLED', updated_at = CURRENT_TIMESTAMP "
        "WHERE id = ? AND restaurant_id = ? AND status IN ('NEW', 'CONFIRMED')",
        (order_id, rid),
    ).rowcount
    if cancelled:
        log_order_event(db, order_id, session["user_id"], "CANCELLED")
        order = db.execute(
            "SELECT promotion_id, customer_id, loyalty_points_redeemed, loyalty_points_earned "
            "FROM orders WHERE id = ?", (order_id,)
        ).fetchone()
        db.execute("UPDATE payments SET status = CASE WHEN provider IN ('SIMULATED', 'NONE') "
                   "THEN 'REFUNDED' ELSE 'REFUND_DUE' END, note = 'Order cancelled' "
                   "WHERE order_id = ? AND status = 'PAID'", (order_id,))
        # Give back a used promotion so the code isn't burned by a cancelled order.
        if order["promotion_id"]:
            db.execute("UPDATE promotions SET used_count = MAX(used_count - 1, 0) WHERE id = ?",
                       (order["promotion_id"],))
        # Reverse any loyalty points already redeemed or earned at checkout.
        if order["customer_id"]:
            if order["loyalty_points_redeemed"]:
                loyalty_ledger(db, order["customer_id"], order_id, order["loyalty_points_redeemed"], "REFUND_REDEEM")
            if order["loyalty_points_earned"]:
                loyalty_ledger(db, order["customer_id"], order_id, -order["loyalty_points_earned"], "REFUND_EARN")
    db.commit()
    if cancelled:
        send_accounting_webhook(db, rid, order_id, "order.cancelled")
    return redirect(url_for("cashier_dashboard"))


# ---------------------------------------------------------------------------
# Kitchen display system
# ---------------------------------------------------------------------------

@app.route("/kitchen")
@login_required("kitchen")
def kitchen_dashboard():
    db = get_db_conn()
    rid = session["restaurant_id"]
    branch = session.get("branch_id")
    orders = db.execute(
        "SELECT o.*, t.number AS table_number FROM orders o JOIN tables_ t ON t.id = o.table_id "
        "WHERE o.restaurant_id = ? AND o.status IN ('PREPARING', 'READY') "
        "AND (? IS NULL OR o.branch_id IS NULL OR o.branch_id = ?) "
        "ORDER BY o.status, o.created_at",
        (rid, branch, branch),
    ).fetchall()
    orders_with_items = []
    for order in orders:
        items = db.execute(
            "SELECT oi.*, mi.name FROM order_items oi JOIN menu_items mi ON mi.id = oi.menu_item_id "
            "WHERE oi.order_id = ?",
            (order["id"],),
        ).fetchall()
        orders_with_items.append({"order": order, "order_items": items})
    return render_template("kitchen_display.html", orders=orders_with_items)


@app.route("/kitchen/order/<int:order_id>/advance", methods=["POST"])
@login_required("kitchen")
def kitchen_advance_order(order_id):
    db = get_db_conn()
    rid = session["restaurant_id"]
    order = db.execute("SELECT * FROM orders WHERE id = ? AND restaurant_id = ?", (order_id, rid)).fetchone()
    if order is None:
        abort(404)
    next_status = {"PREPARING": "READY", "READY": "SERVED"}.get(order["status"])
    if next_status:
        db.execute(
            "UPDATE orders SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
            (next_status, order_id),
        )
        log_order_event(db, order_id, session["user_id"], next_status)
        db.commit()
    return redirect(url_for("kitchen_dashboard"))


# ---------------------------------------------------------------------------
# Waiter dashboard
# ---------------------------------------------------------------------------

@app.route("/waiter")
@login_required("waiter")
def waiter_dashboard():
    db = get_db_conn()
    rid = session["restaurant_id"]
    branch = session.get("branch_id")
    requests_ = db.execute(
        "SELECT sr.*, t.number AS table_number FROM service_requests sr JOIN tables_ t ON t.id = sr.table_id "
        "WHERE sr.restaurant_id = ? AND sr.status IN ('NEW', 'ACCEPTED') "
        "AND (? IS NULL OR t.branch_id IS NULL OR t.branch_id = ?) ORDER BY sr.created_at",
        (rid, branch, branch),
    ).fetchall()
    deliveries = db.execute(
        "SELECT o.*, t.number AS table_number FROM orders o JOIN tables_ t ON t.id = o.table_id "
        "WHERE o.restaurant_id = ? AND o.order_type = 'DELIVERY' AND o.status IN ('READY', 'SERVED') "
        "AND (? IS NULL OR o.branch_id IS NULL OR o.branch_id = ?) ORDER BY o.updated_at",
        (rid, branch, branch),
    ).fetchall()
    reservations = db.execute(
        "SELECT r.* FROM reservations r WHERE r.restaurant_id = ? AND r.status IN ('REQUESTED', 'CONFIRMED') "
        "AND (? IS NULL OR r.branch_id IS NULL OR r.branch_id = ?) ORDER BY r.reservation_time LIMIT 10",
        (rid, branch, branch),
    ).fetchall()
    tables = db.execute("SELECT * FROM tables_ WHERE restaurant_id = ? AND active = 1 AND is_virtual = 0 "
                        "ORDER BY CAST(number AS INTEGER), number", (rid,)).fetchall()
    return render_template("waiter_dashboard.html", requests=requests_, deliveries=deliveries,
                           reservations=reservations, tables=tables)


@app.route("/waiter/order/<int:order_id>/advance-delivery", methods=["POST"])
@login_required("waiter")
def waiter_advance_delivery(order_id):
    db = get_db_conn()
    rid = session["restaurant_id"]
    order = db.execute("SELECT * FROM orders WHERE id = ? AND restaurant_id = ? AND order_type = 'DELIVERY'",
                       (order_id, rid)).fetchone()
    if order is None:
        abort(404)
    next_status = {"READY": "SERVED", "SERVED": "COMPLETED"}.get(order["status"])
    if next_status:
        db.execute("UPDATE orders SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
                   (next_status, order_id))
        log_order_event(db, order_id, session["user_id"], next_status)
        db.commit()
    return redirect(url_for("waiter_dashboard"))


@app.route("/waiter/request/<int:request_id>/advance", methods=["POST"])
@login_required("waiter")
def waiter_advance_request(request_id):
    db = get_db_conn()
    rid = session["restaurant_id"]
    req = db.execute(
        "SELECT * FROM service_requests WHERE id = ? AND restaurant_id = ?", (request_id, rid)
    ).fetchone()
    if req is None:
        abort(404)
    next_status = {"NEW": "ACCEPTED", "ACCEPTED": "COMPLETED"}.get(req["status"])
    if next_status == "ACCEPTED":
        db.execute("UPDATE service_requests SET status = 'ACCEPTED', accepted_by = ?, "
                   "accepted_at = CURRENT_TIMESTAMP WHERE id = ?", (session["user_id"], request_id))
        db.commit()
    elif next_status == "COMPLETED":
        db.execute("UPDATE service_requests SET status = 'COMPLETED', completed_by = ?, "
                   "completed_at = CURRENT_TIMESTAMP WHERE id = ?", (session["user_id"], request_id))
        db.commit()
    return redirect(url_for("waiter_dashboard"))


# ---------------------------------------------------------------------------
# Lightweight JSON status polling (used by the customer order-status page)
# ---------------------------------------------------------------------------

@app.route("/api/order/<int:order_id>/status")
def api_order_status(order_id):
    db = get_db_conn()
    order = db.execute("SELECT status, payment_status FROM orders WHERE id = ?", (order_id,)).fetchone()
    if order is None:
        abort(404)
    return jsonify({"status": order["status"], "payment_status": order["payment_status"]})


if __name__ == "__main__":
    init_db()
    seed_demo_data()
    app.run(debug=os.environ.get("NEXORA_DEBUG") == "1", host="0.0.0.0", port=int(os.environ.get("PORT", 5000)))
