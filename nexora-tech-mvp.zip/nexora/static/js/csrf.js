// Adds the CSRF token to every POST form and exposes it for fetch() calls.
(function () {
  var m = document.querySelector('meta[name="csrf-token"]');
  if (!m) return;
  var token = m.content;
  document.querySelectorAll('form').forEach(function (f) {
    if ((f.method || '').toLowerCase() !== 'post' || f.querySelector('input[name="_csrf"]')) return;
    var i = document.createElement('input');
    i.type = 'hidden'; i.name = '_csrf'; i.value = token;
    f.appendChild(i);
  });
  window.csrfToken = token;
})();
