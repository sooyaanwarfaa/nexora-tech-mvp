"""Production entry point:  gunicorn wsgi:app"""
import os
from app import app
from db import init_db, seed_demo_data

init_db()
if os.environ.get("NEXORA_SEED_DEMO") == "1":  # demo data only when explicitly requested
    seed_demo_data()
