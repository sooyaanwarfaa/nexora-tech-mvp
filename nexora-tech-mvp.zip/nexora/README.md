# Nexora Tech — MVP

A working slice of the Nexora Tech platform described in the business plan: QR-based
customer ordering, a cashier queue, a kitchen display, a waiter call-system, and an
admin dashboard for menu/table/staff management. Built with Flask + SQLite so it runs
anywhere with just Python — no external services required.

## What's included (Phase 1 / MVP scope)

- **Customer flow** — scan a table's link → browse menu → cart → simulated checkout
  (goes through the payment flow described below) → live order-status
  page → Call Waiter / Request Bill / Request Water / Assistance.
- **Cashier dashboard** — see new paid orders, view details, send to kitchen, cancel.
- **Kitchen display** — PREPARING → READY → SERVED, grouped by table.
- **Waiter dashboard** — NEW → ACCEPTED → COMPLETED service requests.
- **Admin dashboard** — revenue/order stats, plus full management with Active/Inactive
  switches:
  - **Restaurant / hotel details** — name, address, phone (name shows on customer menu and staff header)
  - **Menu** — add, edit, rename categories, activate/deactivate categories and items, safe delete
    (an item that appears in past orders is made inactive instead of deleted)
  - **Tables** — add, rename, activate/deactivate, issue a new QR link (old printed QR stops working)
  - **Staff** — add, change role, reset password, activate/deactivate (inactive staff are logged out
    and can't sign in; you can't deactivate yourself or the last active admin)
- **Login** — session-based auth with hashed passwords, one role per account
  (admin / cashier / kitchen / waiter).

## Phase 2 (now included)

- **Inventory management** — track stock items (kg, litres, pcs…), link them to menu
  items as a per-portion "recipe," and stock is deducted automatically the moment a
  cashier sends an order to the kitchen (once per order, never twice). An item shows
  as "Sold out" to customers, and can't be added to a cart, once its ingredients run
  out. Dashboard flags anything at or below its low-stock threshold.
- **Staff performance** — per-person counts and average response times for cashiers
  (orders sent / cancelled, time to confirm), kitchen (orders ready / served, prep
  time), and waiters (requests accepted / completed, response time), filterable by
  24h / 7d / 30d / all-time.
- **Discounts & promotions** — percent or fixed-amount, with an optional code,
  minimum order, date range, and max-uses cap. Promotions with no code apply
  automatically; only the single best discount is applied per order. A promotion
  used on a real order can't be deleted (it's deactivated instead, to keep order
  history accurate); cancelling an order that used one gives the use back.
- **Customer feedback** — a 1–5 star rating with an optional comment, collected once
  an order is ready/served, one submission per order. Admin sees the average rating,
  a star-distribution bar, and a filterable review list.

## Phase 3 (now included)

- **Multi-branch** — add branches under Admin → Branches, then assign each table and
  each staff account to one. Staff assigned to a branch only see that branch's
  orders/kitchen/service requests; staff left unassigned see everything (so a single
  location needs zero setup here).
- **Customer accounts** — customers can sign up / log in with a phone number and PIN
  right from the menu page (guest checkout still works with no account).
- **Loyalty** — logged-in customers earn 1 point per $1 spent (after discounts) and
  can redeem 100 points for $1 off at checkout. Cancelling an order refunds both the
  points it earned and any it redeemed. Admin can view balances and adjust points
  manually under Admin → Customers.
- **Reservations** — a public booking form at each restaurant's page; Admin →
  Reservations (and the waiter dashboard) can confirm, seat with a table, mark
  no-show, or cancel.
- **Delivery** — the same public page has a "Start an Order" flow that reuses the
  entire dine-in ordering system (menu, cart, promos, loyalty) via a disposable
  "virtual table," adds a flat delivery fee, and hands off from kitchen to a
  waiter-run "Out for Delivery → Delivered" flow.

Every restaurant now has a public order page at `/r/<restaurant_id>` (shown on the
admin dashboard) for delivery and reservations — separate from the per-table QR
links used for dine-in.

## Phase 4 (now included)

- **Public API** — Admin → API Keys generates a bearer token (shown once) that
  authenticates read access to `/api/v1/menu`, `/orders`, `/orders/<id>`,
  `/inventory`, `/customers`, and `/reservations` (GET and POST) via
  `Authorization: Bearer <key>`. Keys can be revoked, and last-used time is
  tracked. Built for connecting a website, a delivery aggregator, or a
  third-party dashboard.
- **Accounting integration** — Admin → Accounting lets you set a webhook URL that
  receives a JSON POST every time an order is paid or cancelled (subtotal,
  discount, delivery fee, total). A failed or slow webhook never blocks checkout.
  The same page also has one-click CSV exports (transactions, and a daily sales
  summary) for manual import into QuickBooks, Xero, or a spreadsheet.
- **Advanced permissions** — Admin → Permissions lets one admin restrict exactly
  which admin areas another admin account can use (e.g. a floor manager who can
  run menu/inventory/promotions but can't touch staff, permissions, or billing).
  An admin can't change their own permissions, and the system won't let the last
  admin holding the Permissions permission lose it, so lockout isn't possible.
  Every staff/permission/settings/promotion/API-key/accounting change is recorded
  in Admin → Audit Log.

## Payments & QR codes (now included)

- **Real QR images** — Admin → Tables shows a scannable QR for every table (plus the public
  order page on the dashboard). Download any as SVG, or use **Print all QR cards** for a
  ready-to-print sheet. Generated in pure Python (`qr.py`) — no extra packages.
  Set `NEXORA_PUBLIC_URL` (e.g. `https://order.myrestaurant.com`) so printed codes point at your real domain.
- **Payment flow** — Checkout → payment page → provider confirmation → order reaches the cashier.
  Until payment is confirmed the order stays a cart (`PENDING`) and never reaches cashier/kitchen.
  - Every attempt gets a unique **Transaction ID**; re-clicking or refreshing resumes the same open payment.
  - Failure shows *"Payment was not completed. Please try again."* and the order stays unpaid.
  - Changing the cart voids the pending payment; unpaid attempts expire after 30 minutes.
  - Confirmations are idempotent (double webhooks / double clicks can't create two orders or double-award points).
  - Money that arrives for an order that can't use it, and cancelled paid orders, are flagged **REFUND DUE**.
  - Admin → **Payments**: choose provider, see transactions, mark refunds done (permission `payments.manage`).
- **Providers** — `SIMULATED` (default demo gateway) and `GATEWAY` (generic hosted checkout).
  Configure the gateway with env vars `NEXORA_PAY_API_URL`, `NEXORA_PAY_API_KEY`,
  `NEXORA_PAY_WEBHOOK_SECRET` (optional `NEXORA_PAY_CURRENCY`). Contract:
  - Nexora POSTs `{reference, amount, currency, customer_phone, callback_url, return_url}` and expects `{checkout_url, provider_ref}`.
  - The provider POSTs `{reference, status: SUCCESS|FAILED, amount, provider_ref}` to `/webhooks/payments`
    with header `X-Nexora-Signature` = hex HMAC-SHA256 of the raw body using the webhook secret.
  - Zaad / e-Dahab / EVC Plus have no verified API in this project: adapt `initiate()` and
    `parse_webhook()` in `payments.py` to your provider's real API once you have credentials.

## Setup

```bash
cd nexora
pip install flask
python app.py
```

Upgrading from any earlier version (Phase 1 through 3)? Just run it again — new
tables and columns are added automatically and existing orders, menu items and
logins are left untouched.

The first run creates `nexora.db` and seeds one demo restaurant with a menu, 8 tables,
and one login per role:

| Username | Password    | Role    |
|----------|-------------|---------|
| admin    | admin123    | admin   |
| cashier  | cashier123  | cashier |
| kitchen  | kitchen123  | kitchen |
| waiter   | waiter123   | waiter  |

Then open **http://localhost:5000**.

- Staff log in at `/login` and land on their dashboard.
- To try the customer flow, log in as admin → **Manage Tables** → copy a table's
  link (looks like `/t/<token>`) → open it in another tab or your phone.

## Branding

The Nexora Tech logo (`static/img/`) appears in the top bar of every page, on the login card, on printed QR cards, as the favicon, and as a short splash screen the first time the site is opened in a browser session.

## GitHub

CI runs the tests on every push/PR (`.github/workflows/ci.yml`). Locally:

```bash
pip install -r requirements-dev.txt
python -m pytest -q
```

Copy `.env.example` to `.env` for local settings (it's git-ignored, as are `nexora.db` and `.secret_key`).

## Project layout

```
nexora/
  app.py              Flask routes (all roles)
  db.py               SQLite connection + demo data seeding
  schema.sql          Database schema
  templates/          Jinja2 templates, one per screen
  static/css,js/       Styling
```

## Going live (production)

```bash
cp .env.example .env        # set NEXORA_SECRET_KEY (long random string) and NEXORA_PUBLIC_URL (https://...)
docker compose up -d --build
```

- With `NEXORA_ENV=production` the app refuses to start without `NEXORA_SECRET_KEY`.
- Served by **gunicorn** (no Flask dev server / debug mode). Without Docker: `gunicorn wsgi:app`.
- **CSRF protection** is on for every POST form (token added automatically by `static/js/csrf.js`);
  session cookies are HttpOnly, SameSite=Lax and Secure on https; basic security headers are sent.
- First real setup: `python manage.py init "Restaurant name" admin 'password'` (inside the container: `docker compose exec nexora python manage.py init ...`), then `add-user` / `set-password`.
- The database lives in the `/data` volume (`NEXORA_DB_PATH`) — back it up. First start creates an
  empty database; demo data is only loaded when `NEXORA_SEED_DEMO=1`. **Change the demo passwords**
  (admin/admin123 …) before real use, and put the app behind HTTPS (Caddy / nginx / your host).
- SQLite is fine for a pilot; run a single gunicorn process (the Docker image does).

## Suggested next steps

1. Get sandbox credentials from your mobile-money provider and adapt `payments.py` to its exact API
   (the only item that needs outside access — everything else above is done).
2. Move to PostgreSQL once you outgrow one server / one gunicorn process.
