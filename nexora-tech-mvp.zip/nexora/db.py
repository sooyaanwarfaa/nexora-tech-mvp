import os
import sqlite3
import secrets
from pathlib import Path

DB_PATH = Path(os.environ.get("NEXORA_DB_PATH") or Path(__file__).parent / "nexora.db")
SCHEMA_PATH = Path(__file__).parent / "schema.sql"


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    conn = get_db()
    with open(SCHEMA_PATH) as f:
        conn.executescript(f.read())
    migrate(conn)
    conn.commit()
    conn.close()


# Columns added after the first release. Lets an existing nexora.db upgrade in place.
MIGRATIONS = [
    ("restaurants", "address", "TEXT DEFAULT ''"),
    ("restaurants", "phone", "TEXT DEFAULT ''"),
    ("users", "active", "INTEGER NOT NULL DEFAULT 1"),
    ("tables_", "active", "INTEGER NOT NULL DEFAULT 1"),
    ("categories", "active", "INTEGER NOT NULL DEFAULT 1"),
    ("orders", "subtotal", "REAL DEFAULT 0"),
    ("orders", "discount", "REAL DEFAULT 0"),
    ("orders", "promotion_id", "INTEGER"),
    ("orders", "promo_code", "TEXT"),
    ("orders", "placed_at", "TEXT"),
    ("service_requests", "accepted_by", "INTEGER"),
    ("service_requests", "accepted_at", "TEXT"),
    ("service_requests", "completed_by", "INTEGER"),
    ("service_requests", "completed_at", "TEXT"),
    ("tables_", "branch_id", "INTEGER"),
    ("tables_", "is_virtual", "INTEGER NOT NULL DEFAULT 0"),
    ("users", "branch_id", "INTEGER"),
    ("orders", "branch_id", "INTEGER"),
    ("orders", "order_type", "TEXT NOT NULL DEFAULT 'DINE_IN'"),
    ("orders", "customer_id", "INTEGER"),
    ("orders", "delivery_address", "TEXT"),
    ("orders", "delivery_phone", "TEXT"),
    ("orders", "delivery_fee", "REAL NOT NULL DEFAULT 0"),
    ("orders", "loyalty_points_earned", "INTEGER NOT NULL DEFAULT 0"),
    ("orders", "loyalty_points_redeemed", "INTEGER NOT NULL DEFAULT 0"),
    ("orders", "loyalty_redeemed_value", "REAL NOT NULL DEFAULT 0"),
    ("restaurants", "accounting_webhook_url", "TEXT DEFAULT ''"),
    ("users", "revoked_permissions", "TEXT NOT NULL DEFAULT ''"),
    ("restaurants", "payment_provider", "TEXT NOT NULL DEFAULT 'SIMULATED'"),
]


def migrate(conn):
    for table, column, ddl in MIGRATIONS:
        cols = [r["name"] for r in conn.execute(f"PRAGMA table_info({table})")]
        if column not in cols:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {ddl}")
    # Orders placed before Phase 2 have no subtotal / placed_at; fill them in.
    conn.execute("UPDATE orders SET subtotal = total WHERE (subtotal IS NULL OR subtotal = 0) AND total > 0")
    conn.execute("UPDATE orders SET placed_at = created_at WHERE placed_at IS NULL AND status != 'CART'")


def seed_demo_data():
    """Creates one demo restaurant with a menu, tables, and one login per role.
    Safe to call repeatedly -- skips if data already exists."""
    from werkzeug.security import generate_password_hash

    conn = get_db()
    existing = conn.execute("SELECT id FROM restaurants LIMIT 1").fetchone()
    if existing:
        conn.close()
        return

    cur = conn.execute(
        "INSERT INTO restaurants (name) VALUES (?)", ("Demo Restaurant Hargeisa",)
    )
    restaurant_id = cur.lastrowid

    users = [
        ("admin", "admin123", "admin"),
        ("cashier", "cashier123", "cashier"),
        ("kitchen", "kitchen123", "kitchen"),
        ("waiter", "waiter123", "waiter"),
    ]
    for username, password, role in users:
        conn.execute(
            "INSERT INTO users (restaurant_id, username, password_hash, role) VALUES (?, ?, ?, ?)",
            (restaurant_id, username, generate_password_hash(password), role),
        )

    categories = ["Burgers", "Sides", "Drinks"]
    cat_ids = {}
    for i, name in enumerate(categories):
        cur = conn.execute(
            "INSERT INTO categories (restaurant_id, name, sort_order) VALUES (?, ?, ?)",
            (restaurant_id, name, i),
        )
        cat_ids[name] = cur.lastrowid

    items = [
        ("Chicken Burger", "Grilled chicken, lettuce, mayo", 4.50, "Burgers"),
        ("Beef Burger", "Beef patty, cheese, pickles", 5.00, "Burgers"),
        ("French Fries", "Crispy fries with seasoning", 2.00, "Sides"),
        ("Onion Rings", "Battered onion rings", 2.50, "Sides"),
        ("Mango Juice", "Fresh mango juice", 1.50, "Drinks"),
        ("Bottled Water", "500ml still water", 0.75, "Drinks"),
    ]
    for name, desc, price, cat in items:
        conn.execute(
            "INSERT INTO menu_items (restaurant_id, category_id, name, description, price) "
            "VALUES (?, ?, ?, ?, ?)",
            (restaurant_id, cat_ids[cat], name, desc, price),
        )

    ingredients = [
        ("Chicken", "kg", 20, 5), ("Beef", "kg", 20, 5), ("Burger buns", "pcs", 100, 20),
        ("Potatoes", "kg", 30, 8), ("Onions", "kg", 10, 3), ("Mango juice", "litres", 15, 4),
        ("Bottled water", "bottles", 60, 12),
    ]
    inv = {}
    for name, unit, qty, threshold in ingredients:
        cur = conn.execute(
            "INSERT INTO inventory_items (restaurant_id, name, unit, quantity, low_stock_threshold) "
            "VALUES (?, ?, ?, ?, ?)", (restaurant_id, name, unit, qty, threshold))
        inv[name] = cur.lastrowid
        conn.execute(
            "INSERT INTO stock_movements (restaurant_id, inventory_item_id, change, reason) VALUES (?, ?, ?, ?)",
            (restaurant_id, cur.lastrowid, qty, "Opening stock"))
    recipes = {
        "Chicken Burger": [("Chicken", 0.15), ("Burger buns", 1)],
        "Beef Burger": [("Beef", 0.15), ("Burger buns", 1)],
        "French Fries": [("Potatoes", 0.25)],
        "Onion Rings": [("Onions", 0.2)],
        "Mango Juice": [("Mango juice", 0.3)],
        "Bottled Water": [("Bottled water", 1)],
    }
    for item_name, parts in recipes.items():
        item_id = conn.execute("SELECT id FROM menu_items WHERE restaurant_id = ? AND name = ?",
                               (restaurant_id, item_name)).fetchone()["id"]
        for ing, qty in parts:
            conn.execute("INSERT INTO menu_item_ingredients (menu_item_id, inventory_item_id, quantity) "
                         "VALUES (?, ?, ?)", (item_id, inv[ing], qty))

    conn.execute(
        "INSERT INTO promotions (restaurant_id, name, code, kind, value, min_order) "
        "VALUES (?, ?, ?, ?, ?, ?)", (restaurant_id, "Welcome 10% off", "WELCOME10", "PERCENT", 10, 0))

    main_branch = conn.execute(
        "INSERT INTO branches (restaurant_id, name, address, phone) VALUES (?, ?, ?, ?)",
        (restaurant_id, "Main Branch", "Downtown", "0911-000-000"),
    ).lastrowid
    second_branch = conn.execute(
        "INSERT INTO branches (restaurant_id, name, address, phone) VALUES (?, ?, ?, ?)",
        (restaurant_id, "Airport Road Branch", "Airport Road", "0911-000-111"),
    ).lastrowid

    for n in range(1, 9):
        branch = main_branch if n <= 5 else second_branch
        conn.execute(
            "INSERT INTO tables_ (restaurant_id, number, qr_token, branch_id) VALUES (?, ?, ?, ?)",
            (restaurant_id, str(n), secrets.token_urlsafe(8), branch),
        )

    from werkzeug.security import generate_password_hash as gph
    conn.execute(
        "INSERT INTO customers (restaurant_id, name, phone, pin_hash, loyalty_points) VALUES (?, ?, ?, ?, ?)",
        (restaurant_id, "Amina Yusuf", "0911223344", gph("1234"), 50),
    )

    conn.commit()
    conn.close()
