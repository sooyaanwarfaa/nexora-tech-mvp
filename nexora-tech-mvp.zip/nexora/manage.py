"""Setup commands for a real (non-demo) deployment.

  python manage.py init "My Restaurant" admin 'a-strong-password'   # restaurant + first admin
  python manage.py add-user <username> <role> <password>            # role: admin|cashier|kitchen|waiter
  python manage.py set-password <username> <new-password>
"""
import sys
from werkzeug.security import generate_password_hash
from db import get_db, init_db

ROLES = ("admin", "cashier", "kitchen", "waiter")


def main(argv):
    init_db()
    conn = get_db()
    cmd = argv[1] if len(argv) > 1 else ""
    if cmd == "init" and len(argv) == 5:
        if conn.execute("SELECT 1 FROM restaurants LIMIT 1").fetchone():
            sys.exit("Already initialised. Use add-user / set-password.")
        rid = conn.execute("INSERT INTO restaurants (name) VALUES (?)", (argv[2],)).lastrowid
        conn.execute("INSERT INTO users (restaurant_id, username, password_hash, role) VALUES (?, ?, ?, 'admin')",
                     (rid, argv[3], generate_password_hash(argv[4])))
    elif cmd == "add-user" and len(argv) == 5 and argv[3] in ROLES:
        rid = conn.execute("SELECT id FROM restaurants LIMIT 1").fetchone()
        if rid is None:
            sys.exit("Run init first.")
        conn.execute("INSERT INTO users (restaurant_id, username, password_hash, role) VALUES (?, ?, ?, ?)",
                     (rid[0], argv[2], generate_password_hash(argv[4]), argv[3]))
    elif cmd == "set-password" and len(argv) == 4:
        if not conn.execute("UPDATE users SET password_hash = ? WHERE username = ?",
                            (generate_password_hash(argv[3]), argv[2])).rowcount:
            sys.exit("No such user.")
    else:
        sys.exit(__doc__)
    conn.commit()
    print("Done.")


if __name__ == "__main__":
    main(sys.argv)
