"""Dependency-free QR Code generator (byte mode, error-correction level M, versions 1-40).

Usage:  svg = qr_svg("https://example.com/t/abc")   # returns an <svg> string
"""

ECC_CODEWORDS_PER_BLOCK = [10, 16, 26, 18, 24, 16, 18, 22, 22, 26, 30, 22, 22, 24, 24, 28, 28, 26, 26, 26,
                           26, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28]
NUM_ERROR_CORRECTION_BLOCKS = [1, 1, 2, 2, 4, 4, 4, 5, 5, 5, 5, 8, 9, 9, 10, 10, 11, 13, 14, 16,
                               17, 17, 18, 20, 21, 23, 25, 26, 28, 29, 31, 33, 35, 37, 38, 40, 43, 45, 47, 49]
FORMAT_BITS_M = 0  # ECC level M -> format bits 00


def _raw_modules(ver):
    result = (16 * ver + 128) * ver + 64
    if ver >= 2:
        n = ver // 7 + 2
        result -= (25 * n - 10) * n - 55
        if ver >= 7:
            result -= 36
    return result


def _data_codewords(ver):
    return _raw_modules(ver) // 8 - ECC_CODEWORDS_PER_BLOCK[ver - 1] * NUM_ERROR_CORRECTION_BLOCKS[ver - 1]


def _gf_mul(x, y):
    z = 0
    for i in range(7, -1, -1):
        z = (z << 1) ^ ((z >> 7) * 0x11D)
        z ^= ((y >> i) & 1) * x
    return z


def _rs_divisor(degree):
    result = [0] * (degree - 1) + [1]
    root = 1
    for _ in range(degree):
        for j in range(degree):
            result[j] = _gf_mul(result[j], root)
            if j + 1 < degree:
                result[j] ^= result[j + 1]
        root = _gf_mul(root, 2)
    return result


def _rs_remainder(data, divisor):
    result = [0] * len(divisor)
    for b in data:
        factor = b ^ result.pop(0)
        result.append(0)
        for i, coef in enumerate(divisor):
            result[i] ^= _gf_mul(coef, factor)
    return result


def _add_ecc_and_interleave(data, ver):
    nblocks = NUM_ERROR_CORRECTION_BLOCKS[ver - 1]
    ecc_len = ECC_CODEWORDS_PER_BLOCK[ver - 1]
    raw_cw = _raw_modules(ver) // 8
    num_short = nblocks - raw_cw % nblocks
    short_len = raw_cw // nblocks
    divisor = _rs_divisor(ecc_len)
    blocks, k = [], 0
    for i in range(nblocks):
        dat = data[k:k + short_len - ecc_len + (0 if i < num_short else 1)]
        k += len(dat)
        ecc = _rs_remainder(dat, divisor)
        if i < num_short:
            dat = dat + [0]  # placeholder so all blocks line up during interleave
        blocks.append(dat + ecc)
    result = []
    for i in range(len(blocks[0])):
        for j, blk in enumerate(blocks):
            if i != short_len - ecc_len or j >= num_short:
                result.append(blk[i])
    return result


def _bch_format(mask):
    data = (FORMAT_BITS_M << 3) | mask
    rem = data
    for _ in range(10):
        rem = (rem << 1) ^ ((rem >> 9) * 0x537)
    return ((data << 10) | rem) ^ 0x5412


def _bch_version(ver):
    rem = ver
    for _ in range(12):
        rem = (rem << 1) ^ ((rem >> 11) * 0x1F25)
    return (ver << 12) | rem


class _Matrix:
    def __init__(self, ver):
        self.ver = ver
        self.size = ver * 4 + 17
        self.m = [[False] * self.size for _ in range(self.size)]
        self.func = [[False] * self.size for _ in range(self.size)]
        self._draw_function_patterns()

    def _set(self, x, y, dark):
        self.m[y][x] = dark
        self.func[y][x] = True

    def _align_positions(self):
        if self.ver == 1:
            return []
        n = self.ver // 7 + 2
        step = 26 if self.ver == 32 else (self.ver * 4 + n * 2 + 1) // (n * 2 - 2) * 2
        res = [self.size - 7 - i * step for i in range(n - 1)] + [6]
        return res[::-1]

    def _draw_function_patterns(self):
        s = self.size
        for i in range(s):
            self._set(6, i, i % 2 == 0)
            self._set(i, 6, i % 2 == 0)
        for cx, cy in ((3, 3), (s - 4, 3), (3, s - 4)):
            for dy in range(-4, 5):
                for dx in range(-4, 5):
                    x, y = cx + dx, cy + dy
                    if 0 <= x < s and 0 <= y < s:
                        self._set(x, y, max(abs(dx), abs(dy)) not in (2, 4))
        pos = self._align_positions()
        for i, cx in enumerate(pos):
            for j, cy in enumerate(pos):
                if (i == 0 and j == 0) or (i == 0 and j == len(pos) - 1) or (i == len(pos) - 1 and j == 0):
                    continue
                for dy in range(-2, 3):
                    for dx in range(-2, 3):
                        self._set(cx + dx, cy + dy, max(abs(dx), abs(dy)) != 1)
        self.draw_format(0)
        if self.ver >= 7:
            bits = _bch_version(self.ver)
            for i in range(18):
                b = (bits >> i) & 1 == 1
                a, c = s - 11 + i % 3, i // 3
                self._set(a, c, b)
                self._set(c, a, b)

    def draw_format(self, mask):
        bits = _bch_format(mask)
        s = self.size
        bit = lambda i: (bits >> i) & 1 == 1
        for i in range(6):
            self._set(8, i, bit(i))
        self._set(8, 7, bit(6))
        self._set(8, 8, bit(7))
        self._set(7, 8, bit(8))
        for i in range(9, 15):
            self._set(14 - i, 8, bit(i))
        for i in range(8):
            self._set(s - 1 - i, 8, bit(i))
        for i in range(8, 15):
            self._set(8, s - 15 + i, bit(i))
        self._set(8, s - 8, True)  # always-dark module

    def draw_codewords(self, data):
        s, i = self.size, 0
        for right in range(s - 1, 0, -2):
            if right <= 6:
                right -= 1
            for vert in range(s):
                for j in range(2):
                    x = right - j
                    upward = ((right + 1) & 2) == 0
                    y = s - 1 - vert if upward else vert
                    if not self.func[y][x] and i < len(data) * 8:
                        self.m[y][x] = (data[i >> 3] >> (7 - (i & 7))) & 1 == 1
                        i += 1

    def apply_mask(self, mask):
        for y in range(self.size):
            for x in range(self.size):
                inv = [(x + y) % 2 == 0, y % 2 == 0, x % 3 == 0, (x + y) % 3 == 0,
                       (x // 3 + y // 3) % 2 == 0, x * y % 2 + x * y % 3 == 0,
                       (x * y % 2 + x * y % 3) % 2 == 0, ((x + y) % 2 + x * y % 3) % 2 == 0][mask]
                if inv and not self.func[y][x]:
                    self.m[y][x] = not self.m[y][x]

    def penalty(self):
        s, m, total = self.size, self.m, 0
        for lines in (m, [list(c) for c in zip(*m)]):
            for row in lines:
                run = 1
                for i in range(1, s):
                    if row[i] == row[i - 1]:
                        run += 1
                        if run == 5:
                            total += 3
                        elif run > 5:
                            total += 1
                    else:
                        run = 1
                str_row = "".join("1" if v else "0" for v in row)
                total += 40 * (str_row.count("10111010000") + str_row.count("00001011101"))
        for y in range(s - 1):
            for x in range(s - 1):
                if m[y][x] == m[y][x + 1] == m[y + 1][x] == m[y + 1][x + 1]:
                    total += 3
        dark = sum(sum(r) for r in m)
        k = (abs(dark * 20 - s * s * 10) + s * s - 1) // (s * s) - 1
        return total + max(k, 0) * 10


def make_matrix(text):
    """Returns a list of rows of booleans (True = dark module), without the quiet zone."""
    raw = text.encode("utf-8")
    ver = next((v for v in range(1, 41) if 4 + (8 if v < 10 else 16) + len(raw) * 8 <= _data_codewords(v) * 8), None)
    if ver is None:
        raise ValueError("Text too long for a QR code")
    bits = [0, 1, 0, 0]
    count_bits = 8 if ver < 10 else 16
    bits += [(len(raw) >> i) & 1 for i in range(count_bits - 1, -1, -1)]
    for b in raw:
        bits += [(b >> i) & 1 for i in range(7, -1, -1)]
    cap = _data_codewords(ver) * 8
    bits += [0] * min(4, cap - len(bits))
    bits += [0] * (-len(bits) % 8)
    data = [int("".join(map(str, bits[i:i + 8])), 2) for i in range(0, len(bits), 8)]
    pad = 0xEC
    while len(data) < cap // 8:
        data.append(pad)
        pad ^= 0xEC ^ 0x11
    final = _add_ecc_and_interleave(data, ver)
    best = None
    for mask in range(8):
        mx = _Matrix(ver)
        mx.draw_codewords(final)
        mx.apply_mask(mask)
        mx.draw_format(mask)
        p = mx.penalty()
        if best is None or p < best[0]:
            best = (p, mx)
    return best[1].m


def qr_svg(text, border=4, scale=1):
    m = make_matrix(text)
    n = len(m) + border * 2
    rects = "".join(f"M{x + border},{y + border}h1v1h-1z" for y, row in enumerate(m) for x, v in enumerate(row) if v)
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {n} {n}" shape-rendering="crispEdges" '
            f'role="img" aria-label="QR code"><rect width="100%" height="100%" fill="#fff"/>'
            f'<path d="{rects}" fill="#000"/></svg>')
