import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import pytest

os.environ["NEXORA_PAY_WEBHOOK_SECRET"] = "test-secret"
os.environ["NEXORA_PAY_API_URL"] = "http://127.0.0.1:9/unreachable"


@pytest.fixture()
def env(tmp_path, monkeypatch):
    import db as dbmod
    monkeypatch.setattr(dbmod, "DB_PATH", tmp_path / "t.db")
    import app as A
    A.app.config["CSRF_DISABLED"] = True  # CSRF itself is tested separately below
    A.init_db(); A.seed_demo_data()
    conn = A.get_db()
    tok = conn.execute("SELECT qr_token FROM tables_ WHERE is_virtual = 0 LIMIT 1").fetchone()[0]
    return A, A.app.test_client(), conn, tok


def last_order(conn):
    return conn.execute("SELECT status, payment_status FROM orders ORDER BY id DESC LIMIT 1").fetchone()


def start(c, tok):
    c.post(f"/t/{tok}/cart/add", data={"item_id": 1, "qty": 2})
    return c.post(f"/t/{tok}/checkout").location.rsplit("/", 1)[1]


def test_order_waits_for_payment_and_duplicates_resume(env):
    A, c, conn, tok = env
    txn = start(c, tok)
    assert tuple(last_order(conn)) == ("CART", "PENDING")
    assert c.post(f"/t/{tok}/checkout").location.endswith(txn)


def test_decline_then_retry_then_double_approve(env):
    A, c, conn, tok = env
    txn = start(c, tok)
    c.post(f"/t/{tok}/pay/{txn}/simulate", data={"result": "decline"})
    assert b"Payment was not completed" in c.get(f"/t/{tok}/pay/{txn}").data
    txn2 = c.post(f"/t/{tok}/checkout").location.rsplit("/", 1)[1]
    assert txn2 != txn
    for _ in range(2):
        c.post(f"/t/{tok}/pay/{txn2}/simulate", data={"result": "approve"})
    assert tuple(last_order(conn)) == ("NEW", "PAID")
    assert conn.execute("SELECT COUNT(*) FROM orders WHERE status = 'NEW'").fetchone()[0] == 1


def test_cart_change_voids_pending_payment(env):
    A, c, conn, tok = env
    start(c, tok)
    c.post(f"/t/{tok}/cart/add", data={"item_id": 3, "qty": 1})
    assert conn.execute("SELECT status FROM payments ORDER BY id DESC").fetchone()[0] == "VOIDED"


def test_webhook_signature_amount_and_idempotency(env):
    A, c, conn, tok = env
    import payments
    conn.execute("UPDATE restaurants SET payment_provider = 'GATEWAY'"); conn.commit()
    c.post(f"/t/{tok}/cart/add", data={"item_id": 1, "qty": 1})
    oid = conn.execute("SELECT id, total FROM orders WHERE status = 'CART'").fetchone()
    conn.execute("INSERT INTO payments (restaurant_id, order_id, transaction_id, provider, amount) "
                 "VALUES (1, ?, 'TXN-T1', 'GATEWAY', ?)", (oid["id"], oid["total"])); conn.commit()

    def hook(body, sig=None):
        raw = json.dumps(body).encode()
        return c.post("/webhooks/payments", data=raw,
                      headers={"X-Nexora-Signature": payments.sign(raw) if sig is None else sig})
    ok = {"reference": "TXN-T1", "status": "SUCCESS", "amount": oid["total"]}
    assert hook(ok, "bad").status_code == 401
    assert hook({**ok, "amount": oid["total"] + 1}).status_code == 400
    assert hook(ok).status_code == 200 and hook(ok).status_code == 200
    assert conn.execute("SELECT status FROM orders WHERE id = ?", (oid["id"],)).fetchone()[0] == "NEW"


def test_cancelling_paid_order_flags_refund(env):
    A, c, conn, tok = env
    txn = start(c, tok)
    c.post(f"/t/{tok}/pay/{txn}/simulate", data={"result": "approve"})
    oid = conn.execute("SELECT id FROM orders ORDER BY id DESC").fetchone()[0]
    cc = A.app.test_client(); cc.post("/login", data={"username": "cashier", "password": "cashier123"})
    cc.post(f"/cashier/order/{oid}/cancel")
    assert conn.execute("SELECT status FROM payments WHERE order_id = ?", (oid,)).fetchone()[0] == "REFUNDED"


def test_qr_encoder_and_admin_routes(env):
    A, c, conn, tok = env
    import qr
    assert qr.qr_svg("https://example.com/t/abc").startswith("<svg")
    c.post("/login", data={"username": "admin", "password": "admin123"})
    for url in ["/admin/tables", "/admin/tables/print", "/admin/payments", "/admin/tables/1/qr.svg"]:
        assert c.get(url).status_code == 200


def test_logo_on_every_page(env):
    A, c, conn, tok = env
    for url in ["/login", f"/t/{tok}", "/r/1"]:
        html = c.get(url).data
        assert b"img/logo-white.png" in html or b"img/logo-navy.png" in html, url
        assert b"img/favicon.png" in html, url
    assert c.get("/static/img/logo-white.png").status_code == 200


def paid_order(A, c, conn, tok):
    txn = start(c, tok)
    c.post(f"/t/{tok}/pay/{txn}/simulate", data={"result": "approve"})
    return conn.execute("SELECT id FROM orders ORDER BY id DESC").fetchone()[0]


def login(A, user):
    cl = A.app.test_client()
    cl.post("/login", data={"username": user, "password": f"{user}123"})
    return cl


def status(conn, oid):
    return conn.execute("SELECT status FROM orders WHERE id = ?", (oid,)).fetchone()[0]


def test_order_state_machine_happy_path(env):
    A, c, conn, tok = env
    oid = paid_order(A, c, conn, tok)
    assert status(conn, oid) == "NEW"
    login(A, "cashier").post(f"/cashier/order/{oid}/send-to-kitchen")
    assert status(conn, oid) == "PREPARING"
    kitchen = login(A, "kitchen")
    kitchen.post(f"/kitchen/order/{oid}/advance"); assert status(conn, oid) == "READY"
    kitchen.post(f"/kitchen/order/{oid}/advance"); assert status(conn, oid) == "SERVED"
    kitchen.post(f"/kitchen/order/{oid}/advance"); assert status(conn, oid) == "SERVED"  # end of the line


def test_state_machine_blocks_illegal_moves(env):
    A, c, conn, tok = env
    oid = paid_order(A, c, conn, tok)
    cashier = login(A, "cashier")
    login(A, "kitchen").post(f"/kitchen/order/{oid}/advance")
    assert status(conn, oid) == "NEW"            # kitchen can't skip the cashier
    cashier.post(f"/cashier/order/{oid}/send-to-kitchen")
    cashier.post(f"/cashier/order/{oid}/cancel")
    assert status(conn, oid) == "PREPARING"      # can't cancel once cooking
    cashier.post(f"/cashier/order/{oid}/send-to-kitchen")
    assert status(conn, oid) == "PREPARING"


def test_unpaid_cart_never_reaches_staff(env):
    A, c, conn, tok = env
    start(c, tok)
    assert status(conn, conn.execute("SELECT id FROM orders").fetchone()[0]) == "CART"
    assert b"Order #" not in login(A, "kitchen").get("/kitchen").data


def test_csrf_blocks_forged_posts_but_allows_tokened_ones(env):
    A, c, conn, tok = env
    A.app.config["CSRF_DISABLED"] = False
    assert c.post("/login", data={"username": "admin", "password": "admin123"}).status_code == 400
    page = c.get("/login").data.decode()
    token = page.split('name="csrf-token" content="')[1].split('"')[0]
    r = c.post("/login", data={"username": "admin", "password": "admin123", "_csrf": token})
    assert r.status_code == 302
    assert c.post("/login", data={"_csrf": "wrong"}).status_code == 400


def test_security_headers_and_webhook_exempt_from_csrf(env):
    A, c, conn, tok = env
    A.app.config["CSRF_DISABLED"] = False
    assert c.get("/login").headers["X-Content-Type-Options"] == "nosniff"
    assert c.post("/webhooks/payments", data=b"{}").status_code == 401  # reaches signature check, not CSRF
